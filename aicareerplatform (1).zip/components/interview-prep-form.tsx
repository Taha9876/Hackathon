"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Building2, Briefcase, Code, X, Loader2, Sparkles } from "lucide-react"

interface InterviewPrepFormProps {
  onSubmit: (data: { companyName: string; role: string; technologies: string[] }) => Promise<void>
  isLoading: boolean
}

export function InterviewPrepForm({ onSubmit, isLoading }: InterviewPrepFormProps) {
  const [companyName, setCompanyName] = useState("")
  const [role, setRole] = useState("")
  const [technologies, setTechnologies] = useState<string[]>([])
  const [techInput, setTechInput] = useState("")

  const addTechnology = () => {
    if (techInput.trim() && !technologies.includes(techInput.trim())) {
      setTechnologies([...technologies, techInput.trim()])
      setTechInput("")
    }
  }

  const removeTechnology = (tech: string) => {
    setTechnologies(technologies.filter((t) => t !== tech))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!companyName || !role) return
    await onSubmit({ companyName, role, technologies })
  }

  const commonTechnologies = [
    "JavaScript",
    "TypeScript",
    "React",
    "Node.js",
    "Python",
    "Java",
    "SQL",
    "AWS",
    "Docker",
    "Kubernetes",
    "GraphQL",
    "REST APIs",
  ]

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Sparkles className="h-5 w-5 text-primary" />
          Start Interview Preparation
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Enter your upcoming interview details and we&apos;ll generate personalized preparation materials
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="company" className="flex items-center gap-2 text-foreground">
                <Building2 className="h-4 w-4" />
                Company Name
              </Label>
              <Input
                id="company"
                placeholder="e.g., Google, Stripe, Airbnb"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                required
                className="border-input bg-secondary text-foreground placeholder:text-muted-foreground"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role" className="flex items-center gap-2 text-foreground">
                <Briefcase className="h-4 w-4" />
                Role / Position
              </Label>
              <Input
                id="role"
                placeholder="e.g., Senior Frontend Engineer"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                required
                className="border-input bg-secondary text-foreground placeholder:text-muted-foreground"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2 text-foreground">
              <Code className="h-4 w-4" />
              Key Technologies (Optional)
            </Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add a technology..."
                value={techInput}
                onChange={(e) => setTechInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addTechnology())}
                className="border-input bg-secondary text-foreground placeholder:text-muted-foreground"
              />
              <Button
                type="button"
                variant="outline"
                onClick={addTechnology}
                className="border-border text-foreground hover:bg-secondary bg-transparent"
              >
                Add
              </Button>
            </div>

            {/* Selected Technologies */}
            {technologies.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {technologies.map((tech) => (
                  <Badge key={tech} variant="secondary" className="gap-1 bg-primary/10 text-primary">
                    {tech}
                    <button
                      type="button"
                      onClick={() => removeTechnology(tech)}
                      className="ml-1 rounded-full hover:bg-primary/20"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            {/* Quick Add Technologies */}
            <div className="pt-2">
              <p className="mb-2 text-xs text-muted-foreground">Quick add:</p>
              <div className="flex flex-wrap gap-1">
                {commonTechnologies
                  .filter((t) => !technologies.includes(t))
                  .slice(0, 8)
                  .map((tech) => (
                    <Badge
                      key={tech}
                      variant="outline"
                      className="cursor-pointer border-border text-muted-foreground hover:border-primary hover:text-primary"
                      onClick={() => setTechnologies([...technologies, tech])}
                    >
                      + {tech}
                    </Badge>
                  ))}
              </div>
            </div>
          </div>

          <Button
            type="submit"
            disabled={!companyName || !role || isLoading}
            className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating Prep Materials...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Generate Interview Prep
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

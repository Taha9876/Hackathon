"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Sparkles,
  TrendingUp,
  BookOpen,
  Target,
  FileText,
  MessageSquare,
  DollarSign,
  RefreshCw,
  Lightbulb,
  ChevronRight,
  Star,
  Zap,
} from "lucide-react"

interface Recommendations {
  careerInsights: {
    currentStrengths: string[]
    areasForImprovement: string[]
    marketReadiness: number
    uniqueSellingPoints: string[]
  }
  skillRecommendations: {
    skill: string
    reason: string
    priority: "high" | "medium" | "low"
    resources: string[]
  }[]
  careerPaths: {
    title: string
    fit: number
    requirements: string[]
    timeline: string
  }[]
  resumeTips: {
    section: string
    tip: string
    impact: "high" | "medium" | "low"
  }[]
  interviewFocus: string[]
  salaryInsights: {
    estimatedRange: string
    factors: string[]
  }
}

export function RecommendationsPanel() {
  const [recommendations, setRecommendations] = useState<Recommendations | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchRecommendations = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/recommendations")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to fetch recommendations")
      }

      setRecommendations(data.recommendations)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchRecommendations()
  }, [])

  const priorityColors = {
    high: "bg-red-500/20 text-red-400 border-red-500/30",
    medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    low: "bg-green-500/20 text-green-400 border-green-500/30",
  }

  const impactColors = {
    high: "bg-primary/20 text-primary",
    medium: "bg-accent/20 text-accent",
    low: "bg-muted text-muted-foreground",
  }

  if (isLoading) {
    return (
      <Card className="border-border bg-card">
        <CardContent className="flex flex-col items-center justify-center p-12">
          <div className="relative">
            <div className="h-12 w-12 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <Sparkles className="absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 text-primary" />
          </div>
          <p className="mt-4 text-sm text-muted-foreground">Generating AI-powered recommendations...</p>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="border-border bg-card">
        <CardContent className="flex flex-col items-center justify-center p-12">
          <p className="text-sm text-destructive">{error}</p>
          <Button onClick={fetchRecommendations} variant="outline" className="mt-4 gap-2 bg-transparent">
            <RefreshCw className="h-4 w-4" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    )
  }

  if (!recommendations) return null

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold text-foreground">AI-Powered Recommendations</h2>
        </div>
        <Button onClick={fetchRecommendations} variant="outline" size="sm" className="gap-2 bg-transparent">
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
      </div>

      {/* Market Readiness Score */}
      <Card className="border-primary/30 bg-gradient-to-br from-primary/10 to-accent/10">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Market Readiness Score</p>
              <p className="mt-1 text-4xl font-bold text-foreground">
                {recommendations.careerInsights.marketReadiness}%
              </p>
            </div>
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/20">
              <Target className="h-8 w-8 text-primary" />
            </div>
          </div>
          <Progress value={recommendations.careerInsights.marketReadiness} className="mt-4 h-2" />
        </CardContent>
      </Card>

      {/* Strengths & Improvements */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base text-foreground">
              <Star className="h-4 w-4 text-yellow-500" />
              Your Strengths
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {recommendations.careerInsights.currentStrengths.map((strength, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <Zap className="mt-0.5 h-3 w-3 flex-shrink-0 text-primary" />
                  {strength}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base text-foreground">
              <TrendingUp className="h-4 w-4 text-accent" />
              Areas to Improve
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {recommendations.careerInsights.areasForImprovement.map((area, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <ChevronRight className="mt-0.5 h-3 w-3 flex-shrink-0 text-muted-foreground" />
                  {area}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Unique Selling Points */}
      <Card className="border-border bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Lightbulb className="h-5 w-5 text-yellow-500" />
            What Makes You Stand Out
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {recommendations.careerInsights.uniqueSellingPoints.map((point, i) => (
              <Badge key={i} variant="secondary" className="bg-primary/10 text-primary">
                {point}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Skills to Learn */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <BookOpen className="h-5 w-5 text-primary" />
            Recommended Skills to Learn
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Based on market trends and your current profile
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.skillRecommendations.map((skill, i) => (
              <div key={i} className="rounded-lg border border-border bg-muted/50 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{skill.skill}</span>
                      <Badge variant="outline" className={priorityColors[skill.priority]}>
                        {skill.priority} priority
                      </Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{skill.reason}</p>
                  </div>
                </div>
                {skill.resources.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {skill.resources.map((resource, j) => (
                      <Badge key={j} variant="secondary" className="bg-secondary text-secondary-foreground text-xs">
                        {resource}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Career Paths */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Target className="h-5 w-5 text-primary" />
            Potential Career Paths
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.careerPaths.map((path, i) => (
              <div key={i} className="rounded-lg border border-border bg-muted/50 p-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-foreground">{path.title}</h4>
                  <Badge
                    variant="secondary"
                    className={
                      path.fit >= 80
                        ? "bg-green-500/20 text-green-400"
                        : path.fit >= 60
                          ? "bg-primary/20 text-primary"
                          : "bg-secondary text-secondary-foreground"
                    }
                  >
                    {path.fit}% fit
                  </Badge>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">Timeline: {path.timeline}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {path.requirements.map((req, j) => (
                    <Badge key={j} variant="outline" className="border-border text-muted-foreground text-xs">
                      {req}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Resume Tips */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <FileText className="h-5 w-5 text-primary" />
            Resume Improvement Tips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recommendations.resumeTips.map((tip, i) => (
              <div key={i} className="flex items-start gap-3 rounded-lg bg-muted p-3">
                <Badge variant="secondary" className={impactColors[tip.impact]}>
                  {tip.section}
                </Badge>
                <p className="flex-1 text-sm text-muted-foreground">{tip.tip}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Interview Focus & Salary */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base text-foreground">
              <MessageSquare className="h-4 w-4 text-primary" />
              Interview Focus Areas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {recommendations.interviewFocus.map((focus, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <ChevronRight className="mt-0.5 h-3 w-3 flex-shrink-0 text-primary" />
                  {focus}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base text-foreground">
              <DollarSign className="h-4 w-4 text-green-500" />
              Salary Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-semibold text-foreground">{recommendations.salaryInsights.estimatedRange}</p>
            <p className="mt-2 text-xs text-muted-foreground">Factors that could increase your salary:</p>
            <ul className="mt-1 space-y-1">
              {recommendations.salaryInsights.factors.map((factor, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <TrendingUp className="mt-0.5 h-3 w-3 flex-shrink-0 text-green-500" />
                  {factor}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import {
  Building2,
  Code,
  Users,
  Lightbulb,
  CheckCircle,
  ChevronRight,
  ExternalLink,
  Newspaper,
  Wrench,
} from "lucide-react"
import type { InterviewPrep, TechnicalQuestion } from "@/lib/types"

interface InterviewPrepViewProps {
  prep: InterviewPrep
}

export function InterviewPrepView({ prep }: InterviewPrepViewProps) {
  const [completedQuestions, setCompletedQuestions] = useState<Set<string>>(new Set())

  const toggleQuestion = (id: string) => {
    const newCompleted = new Set(completedQuestions)
    if (newCompleted.has(id)) {
      newCompleted.delete(id)
    } else {
      newCompleted.add(id)
    }
    setCompletedQuestions(newCompleted)
  }

  const getDifficultyColor = (difficulty: TechnicalQuestion["difficulty"]) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-500/20 text-green-400"
      case "medium":
        return "bg-yellow-500/20 text-yellow-400"
      case "hard":
        return "bg-red-500/20 text-red-400"
    }
  }

  const technicalProgress = prep.technicalQuestions.filter((_, i) => completedQuestions.has(`tech-${i}`)).length

  const behavioralProgress = prep.behavioralQuestions.filter((_, i) => completedQuestions.has(`behav-${i}`)).length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">
            {prep.role} at {prep.companyName}
          </h2>
          <div className="mt-2 flex flex-wrap gap-2">
            {prep.technologies.map((tech) => (
              <Badge key={tech} variant="secondary" className="bg-primary/10 text-primary">
                {tech}
              </Badge>
            ))}
          </div>
        </div>
        <div className="flex gap-4 text-sm">
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">
              {technicalProgress}/{prep.technicalQuestions.length}
            </p>
            <p className="text-xs text-muted-foreground">Technical</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-accent">
              {behavioralProgress}/{prep.behavioralQuestions.length}
            </p>
            <p className="text-xs text-muted-foreground">Behavioral</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="company" className="space-y-4">
        <TabsList className="w-full justify-start bg-muted">
          <TabsTrigger value="company" className="data-[state=active]:bg-background">
            <Building2 className="mr-2 h-4 w-4" />
            Company
          </TabsTrigger>
          <TabsTrigger value="technical" className="data-[state=active]:bg-background">
            <Code className="mr-2 h-4 w-4" />
            Technical
          </TabsTrigger>
          <TabsTrigger value="behavioral" className="data-[state=active]:bg-background">
            <Users className="mr-2 h-4 w-4" />
            Behavioral
          </TabsTrigger>
          <TabsTrigger value="tips" className="data-[state=active]:bg-background">
            <Lightbulb className="mr-2 h-4 w-4" />
            Tips
          </TabsTrigger>
        </TabsList>

        {/* Company Insights */}
        <TabsContent value="company" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                  <Building2 className="h-5 w-5 text-primary" />
                  Company Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{prep.companyInsights.overview}</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                  <Users className="h-5 w-5 text-primary" />
                  Culture & Values
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{prep.companyInsights.culture}</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                  <Wrench className="h-5 w-5 text-primary" />
                  Tech Stack
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {prep.companyInsights.techStack.map((tech) => (
                    <Badge key={tech} variant="secondary" className="bg-secondary text-secondary-foreground">
                      {tech}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                  <ChevronRight className="h-5 w-5 text-primary" />
                  Interview Process
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{prep.companyInsights.interviewProcess}</p>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                <Newspaper className="h-5 w-5 text-primary" />
                Recent News & Developments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {prep.companyInsights.recentNews.map((news, i) => (
                  <li key={i} className="flex items-start gap-2 text-muted-foreground">
                    <ExternalLink className="mt-1 h-4 w-4 flex-shrink-0 text-primary" />
                    {news}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Technical Questions */}
        <TabsContent value="technical" className="space-y-4">
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">Technical Questions</CardTitle>
              <CardDescription className="text-muted-foreground">
                {prep.technicalQuestions.length} questions covering {prep.technologies.join(", ")} and related topics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="multiple" className="space-y-2">
                {prep.technicalQuestions.map((q, i) => (
                  <AccordionItem
                    key={i}
                    value={`tech-${i}`}
                    className="rounded-lg border border-border bg-muted/50 px-4"
                  >
                    <AccordionTrigger className="py-4 hover:no-underline">
                      <div className="flex flex-1 items-center gap-3 text-left">
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`h-6 w-6 flex-shrink-0 ${
                            completedQuestions.has(`tech-${i}`) ? "text-green-400" : "text-muted-foreground"
                          }`}
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleQuestion(`tech-${i}`)
                          }}
                        >
                          <CheckCircle className="h-5 w-5" />
                        </Button>
                        <span className="flex-1 font-medium text-foreground">{q.question}</span>
                        <Badge className={getDifficultyColor(q.difficulty)}>{q.difficulty}</Badge>
                        <Badge variant="outline" className="border-border text-muted-foreground">
                          {q.topic}
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-4 pb-4">
                      <div>
                        <h5 className="mb-2 text-sm font-medium text-foreground">Hints:</h5>
                        <ul className="space-y-1">
                          {q.hints.map((hint, j) => (
                            <li key={j} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <Lightbulb className="mt-0.5 h-4 w-4 flex-shrink-0 text-yellow-500" />
                              {hint}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="mb-2 text-sm font-medium text-foreground">Key Points to Cover:</h5>
                        <ul className="space-y-1">
                          {q.keyPoints.map((point, j) => (
                            <li key={j} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <CheckCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                              {point}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Behavioral Questions */}
        <TabsContent value="behavioral" className="space-y-4">
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">Behavioral Questions</CardTitle>
              <CardDescription className="text-muted-foreground">
                Practice with STAR method examples to structure your answers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="multiple" className="space-y-2">
                {prep.behavioralQuestions.map((q, i) => (
                  <AccordionItem
                    key={i}
                    value={`behav-${i}`}
                    className="rounded-lg border border-border bg-muted/50 px-4"
                  >
                    <AccordionTrigger className="py-4 hover:no-underline">
                      <div className="flex flex-1 items-center gap-3 text-left">
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`h-6 w-6 flex-shrink-0 ${
                            completedQuestions.has(`behav-${i}`) ? "text-green-400" : "text-muted-foreground"
                          }`}
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleQuestion(`behav-${i}`)
                          }}
                        >
                          <CheckCircle className="h-5 w-5" />
                        </Button>
                        <span className="flex-1 font-medium text-foreground">{q.question}</span>
                        <Badge variant="outline" className="border-border text-muted-foreground">
                          {q.category}
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pb-4">
                      <div className="rounded-lg bg-card p-4">
                        <h5 className="mb-3 text-sm font-medium text-foreground">STAR Method Example:</h5>
                        <div className="space-y-3">
                          <div>
                            <span className="text-xs font-semibold text-primary">SITUATION</span>
                            <p className="mt-1 text-sm text-muted-foreground">{q.starExample.situation}</p>
                          </div>
                          <div>
                            <span className="text-xs font-semibold text-primary">TASK</span>
                            <p className="mt-1 text-sm text-muted-foreground">{q.starExample.task}</p>
                          </div>
                          <div>
                            <span className="text-xs font-semibold text-primary">ACTION</span>
                            <p className="mt-1 text-sm text-muted-foreground">{q.starExample.action}</p>
                          </div>
                          <div>
                            <span className="text-xs font-semibold text-primary">RESULT</span>
                            <p className="mt-1 text-sm text-muted-foreground">{q.starExample.result}</p>
                          </div>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tips */}
        <TabsContent value="tips" className="space-y-4">
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Lightbulb className="h-5 w-5 text-yellow-500" />
                Interview Preparation Tips
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                Specific tips for your {prep.role} interview at {prep.companyName}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-2">
                {prep.tips.map((tip, i) => (
                  <div key={i} className="flex items-start gap-3 rounded-lg bg-muted p-3">
                    <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                      {i + 1}
                    </div>
                    <p className="text-sm text-muted-foreground">{tip}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Building2,
  MapPin,
  ExternalLink,
  Bookmark,
  BookmarkCheck,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Clock,
  Briefcase,
  Users,
  Calendar,
  TrendingUp,
} from "lucide-react"
import type { JobMatch } from "@/lib/types"

interface JobCardProps {
  job: JobMatch
  onUpdate: (id: string, updates: Partial<JobMatch>) => void
}

export function JobCard({ job, onUpdate }: JobCardProps) {
  const [expanded, setExpanded] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)

  const handleSave = async () => {
    setIsUpdating(true)
    try {
      const response = await fetch(`/api/jobs/${job.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ saved: !job.saved }),
      })
      if (response.ok) {
        onUpdate(job.id, { saved: !job.saved })
      }
    } finally {
      setIsUpdating(false)
    }
  }

  const handleApply = async () => {
    setIsUpdating(true)
    try {
      const response = await fetch(`/api/jobs/${job.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ applied: true, status: "applied" }),
      })
      if (response.ok) {
        onUpdate(job.id, { applied: true, status: "applied" })
        window.open(job.url, "_blank")
      }
    } finally {
      setIsUpdating(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-400"
    if (score >= 60) return "text-primary"
    if (score >= 40) return "text-yellow-400"
    return "text-muted-foreground"
  }

  const getExperienceBadgeColor = (level: string) => {
    switch (level) {
      case "entry":
        return "bg-green-500/20 text-green-400"
      case "mid":
        return "bg-blue-500/20 text-blue-400"
      case "senior":
        return "bg-purple-500/20 text-purple-400"
      case "lead":
        return "bg-orange-500/20 text-orange-400"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const formatSalary = (salary: JobMatch["salary"]) => {
    if (!salary) return null
    const formatter = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: salary.currency || "USD",
      maximumFractionDigits: 0,
    })
    if (salary.min && salary.max) {
      return `${formatter.format(salary.min)} - ${formatter.format(salary.max)}`
    }
    return salary.min ? formatter.format(salary.min) : null
  }

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return null
    const date = new Date(dateStr)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
    if (diffDays === 0) return "Today"
    if (diffDays === 1) return "Yesterday"
    if (diffDays < 7) return `${diffDays} days ago`
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`
    return date.toLocaleDateString()
  }

  return (
    <Card className="border-border bg-card transition-all hover:border-primary/30">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-semibold text-foreground">{job.title}</h3>
              {job.applied && (
                <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                  Applied
                </Badge>
              )}
              <Badge className={getExperienceBadgeColor(job.experienceLevel)}>
                {job.experienceLevel?.charAt(0).toUpperCase() + job.experienceLevel?.slice(1) || "Mid"} Level
              </Badge>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Building2 className="h-4 w-4" />
                {job.company}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                {job.location}
              </span>
              <Badge variant="outline" className="border-border text-xs">
                {job.jobType || "Full-time"}
              </Badge>
              <Badge variant="outline" className="border-border text-xs">
                {job.source}
              </Badge>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-3 text-sm">
              {job.salary && (
                <span className="flex items-center gap-1 text-green-400">
                  <DollarSign className="h-4 w-4" />
                  {formatSalary(job.salary)}/{job.salary.period === "yearly" ? "yr" : "hr"}
                </span>
              )}
              {job.postedDate && (
                <span className="flex items-center gap-1 text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  Posted {formatDate(job.postedDate)}
                </span>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className={`text-2xl font-bold ${getScoreColor(job.compatibilityScore)}`}>
              {job.compatibilityScore}%
            </span>
            <span className="text-xs text-muted-foreground">match</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground">
            <span>Compatibility Score</span>
            <span>{job.compatibilityScore}%</span>
          </div>
          <Progress value={job.compatibilityScore} className="h-2" />
        </div>

        <p className="text-sm text-muted-foreground">{job.description}</p>

        {/* Skills Matched */}
        <div>
          <p className="mb-2 flex items-center gap-1 text-xs font-medium text-green-400">
            <CheckCircle className="h-3 w-3" />
            Skills Matched
          </p>
          <div className="flex flex-wrap gap-1">
            {job.skillsMatched.slice(0, expanded ? undefined : 5).map((skill) => (
              <Badge key={skill} variant="secondary" className="bg-green-500/10 text-xs text-green-400">
                {skill}
              </Badge>
            ))}
            {!expanded && job.skillsMatched.length > 5 && (
              <Badge variant="outline" className="text-xs text-muted-foreground">
                +{job.skillsMatched.length - 5} more
              </Badge>
            )}
          </div>
        </div>

        {job.skillsGap && job.skillsGap.length > 0 && (
          <div>
            <p className="mb-2 flex items-center gap-1 text-xs font-medium text-yellow-400">
              <TrendingUp className="h-3 w-3" />
              Skills to Develop
            </p>
            <div className="flex flex-wrap gap-1">
              {job.skillsGap.slice(0, expanded ? undefined : 3).map((skill) => (
                <Badge key={skill} variant="secondary" className="bg-yellow-500/10 text-xs text-yellow-400">
                  {skill}
                </Badge>
              ))}
              {!expanded && job.skillsGap.length > 3 && (
                <Badge variant="outline" className="text-xs text-muted-foreground">
                  +{job.skillsGap.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Expandable Details */}
        {expanded && (
          <div className="space-y-4 rounded-lg bg-muted p-4">
            {/* Match Reasons */}
            <div>
              <p className="mb-2 text-xs font-medium text-foreground">Why this is a good match:</p>
              <ul className="space-y-1">
                {job.matchReasons.map((reason, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                    {reason}
                  </li>
                ))}
              </ul>
            </div>

            {job.requirements && job.requirements.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-medium text-foreground">Requirements:</p>
                <ul className="space-y-1">
                  {job.requirements.map((req, i) => (
                    <li key={i} className="text-sm text-muted-foreground">
                      • {req}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {job.qualifications && job.qualifications.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-medium text-foreground">Qualifications:</p>
                <ul className="space-y-1">
                  {job.qualifications.map((qual, i) => (
                    <li key={i} className="text-sm text-muted-foreground">
                      • {qual}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {job.responsibilities && job.responsibilities.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-medium text-foreground">Responsibilities:</p>
                <ul className="space-y-1">
                  {job.responsibilities.map((resp, i) => (
                    <li key={i} className="text-sm text-muted-foreground">
                      • {resp}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {job.benefits && job.benefits.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-medium text-foreground">Benefits:</p>
                <div className="flex flex-wrap gap-2">
                  {job.benefits.map((benefit, i) => (
                    <Badge key={i} variant="outline" className="text-xs">
                      {benefit}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {job.companyInfo && (
              <div>
                <p className="mb-2 text-xs font-medium text-foreground">Company Info:</p>
                <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                  {job.companyInfo.industry && (
                    <div className="flex items-center gap-1">
                      <Briefcase className="h-3 w-3" />
                      {job.companyInfo.industry}
                    </div>
                  )}
                  {job.companyInfo.size && (
                    <div className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {job.companyInfo.size}
                    </div>
                  )}
                  {job.companyInfo.founded && (
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Founded {job.companyInfo.founded}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between border-t border-border pt-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(!expanded)}
            className="gap-1 text-muted-foreground hover:text-foreground"
          >
            {expanded ? (
              <>
                <ChevronUp className="h-4 w-4" />
                Show Less
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4" />
                Show More
              </>
            )}
          </Button>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleSave}
              disabled={isUpdating}
              className={`gap-1 border-border ${
                job.saved ? "bg-primary/10 text-primary" : "text-foreground hover:bg-secondary"
              }`}
            >
              {job.saved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
              {job.saved ? "Saved" : "Save"}
            </Button>
            <Button
              size="sm"
              onClick={handleApply}
              disabled={isUpdating || job.applied}
              className="gap-1 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <ExternalLink className="h-4 w-4" />
              {job.applied ? "Applied" : "Apply"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

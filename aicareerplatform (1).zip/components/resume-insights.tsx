"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { User, Briefcase, GraduationCap, Code, Star, MapPin, Mail, Phone, Linkedin, Github, Globe } from "lucide-react"
import type { ParsedResume, Skill } from "@/lib/types"

interface ResumeInsightsProps {
  resume: ParsedResume
}

export function ResumeInsights({ resume }: ResumeInsightsProps) {
  const proficiencyColors: Record<Skill["proficiency"], string> = {
    beginner: "bg-zinc-500/20 text-zinc-400",
    intermediate: "bg-blue-500/20 text-blue-400",
    advanced: "bg-primary/20 text-primary",
    expert: "bg-accent/20 text-accent",
  }

  const proficiencyPercentage: Record<Skill["proficiency"], number> = {
    beginner: 25,
    intermediate: 50,
    advanced: 75,
    expert: 100,
  }

  const skills = Array.isArray(resume?.skills) ? resume.skills : []

  // Group skills by category with null safety
  const skillsByCategory = skills.reduce(
    (acc, skill) => {
      if (!skill || !skill.category) return acc
      const category = skill.category || "Other"
      if (!acc[category]) {
        acc[category] = []
      }
      acc[category].push(skill)
      return acc
    },
    {} as Record<string, Skill[]>,
  )

  const experience = Array.isArray(resume?.experience) ? resume.experience : []
  const education = Array.isArray(resume?.education) ? resume.education : []
  const projects = Array.isArray(resume?.projects) ? resume.projects : []
  const expertiseAreas = Array.isArray(resume?.expertiseAreas) ? resume.expertiseAreas : []

  return (
    <div className="space-y-6">
      {/* Profile Overview */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <User className="h-5 w-5 text-primary" />
            Profile Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-2xl font-bold text-foreground">{resume?.fullName || "Name not found"}</h3>
              <p className="text-muted-foreground">
                {resume?.yearsOfExperience != null
                  ? `${resume.yearsOfExperience} years of experience`
                  : "Experience not specified"}
              </p>
            </div>
            {expertiseAreas.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {expertiseAreas.map((area, index) => (
                  <Badge key={`${area}-${index}`} variant="secondary" className="bg-primary/10 text-primary">
                    {area}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Contact Info */}
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            {resume?.email && (
              <span className="flex items-center gap-1">
                <Mail className="h-4 w-4" /> {resume.email}
              </span>
            )}
            {resume?.phone && (
              <span className="flex items-center gap-1">
                <Phone className="h-4 w-4" /> {resume.phone}
              </span>
            )}
            {resume?.location && (
              <span className="flex items-center gap-1">
                <MapPin className="h-4 w-4" /> {resume.location}
              </span>
            )}
            {resume?.linkedin && (
              <a
                href={resume.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-primary hover:underline"
              >
                <Linkedin className="h-4 w-4" /> LinkedIn
              </a>
            )}
            {resume?.github && (
              <a
                href={resume.github}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-primary hover:underline"
              >
                <Github className="h-4 w-4" /> GitHub
              </a>
            )}
            {resume?.portfolio && (
              <a
                href={resume.portfolio}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-primary hover:underline"
              >
                <Globe className="h-4 w-4" /> Portfolio
              </a>
            )}
          </div>

          {/* Summary */}
          {resume?.summary && (
            <div className="rounded-lg bg-muted p-4">
              <p className="text-sm text-foreground">{resume.summary}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Skills - Only show if we have skills */}
      {skills.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Code className="h-5 w-5 text-primary" />
              Skills Analysis
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              {skills.length} skills identified across {Object.keys(skillsByCategory).length} categories
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {Object.entries(skillsByCategory).map(([category, categorySkills]) => (
              <div key={category} className="space-y-3">
                <h4 className="text-sm font-medium text-foreground">{category}</h4>
                <div className="grid gap-3 sm:grid-cols-2">
                  {categorySkills.map((skill, index) => (
                    <div
                      key={`${skill.name}-${index}`}
                      className="flex items-center justify-between rounded-lg bg-muted p-3"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-foreground">{skill.name}</span>
                        <Badge
                          variant="secondary"
                          className={proficiencyColors[skill.proficiency] || proficiencyColors.intermediate}
                        >
                          {skill.proficiency || "intermediate"}
                        </Badge>
                      </div>
                      <div className="w-20">
                        <Progress value={proficiencyPercentage[skill.proficiency] || 50} className="h-1.5" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Experience - Only show if we have experience */}
      {experience.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Briefcase className="h-5 w-5 text-primary" />
              Work Experience
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {experience.map((exp, index) => (
                <div key={index} className="relative border-l-2 border-border pl-6 pb-6 last:pb-0">
                  <div className="absolute -left-2 top-0 h-4 w-4 rounded-full bg-primary" />
                  <div className="space-y-2">
                    <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                      <h4 className="font-semibold text-foreground">{exp?.title || "Position"}</h4>
                      <span className="text-xs text-muted-foreground">
                        {exp?.startDate || "Start"} - {exp?.current ? "Present" : exp?.endDate || "End"}
                      </span>
                    </div>
                    <p className="text-sm text-primary">
                      {exp?.company || "Company"}
                      {exp?.location && ` • ${exp.location}`}
                    </p>
                    {exp?.description && <p className="text-sm text-muted-foreground">{exp.description}</p>}
                    {Array.isArray(exp?.highlights) && exp.highlights.length > 0 && (
                      <ul className="mt-2 space-y-1">
                        {exp.highlights.map((highlight, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <Star className="mt-1 h-3 w-3 flex-shrink-0 text-accent" />
                            {highlight}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Education - Only show if we have education */}
      {education.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <GraduationCap className="h-5 w-5 text-primary" />
              Education
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {education.map((edu, index) => (
                <div key={index} className="rounded-lg bg-muted p-4">
                  <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                    <h4 className="font-semibold text-foreground">{edu?.degree || "Degree"}</h4>
                    <span className="text-xs text-muted-foreground">{edu?.graduationDate || ""}</span>
                  </div>
                  <p className="text-sm text-primary">
                    {edu?.institution || "Institution"}
                    {edu?.location && ` • ${edu.location}`}
                  </p>
                  {edu?.gpa && <p className="text-sm text-muted-foreground">GPA: {edu.gpa}</p>}
                  {Array.isArray(edu?.highlights) && edu.highlights.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {edu.highlights.map((highlight, i) => (
                        <Badge key={i} variant="outline" className="border-border text-muted-foreground">
                          {highlight}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Projects - Only show if we have projects */}
      {projects.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Code className="h-5 w-5 text-primary" />
              Projects
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2">
              {projects.map((project, index) => (
                <div key={index} className="rounded-lg border border-border bg-muted/50 p-4">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-semibold text-foreground">{project?.name || "Project"}</h4>
                    {project?.url && (
                      <a
                        href={project.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        <Globe className="h-4 w-4" />
                      </a>
                    )}
                  </div>
                  {project?.description && <p className="mt-1 text-sm text-muted-foreground">{project.description}</p>}
                  {Array.isArray(project?.technologies) && project.technologies.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-1">
                      {project.technologies.map((tech, i) => (
                        <Badge key={i} variant="secondary" className="bg-secondary text-secondary-foreground">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {skills.length === 0 && experience.length === 0 && education.length === 0 && projects.length === 0 && (
        <Card className="border-border bg-card">
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">
              No detailed information was extracted from your resume. Please try uploading a different PDF file with
              selectable text.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

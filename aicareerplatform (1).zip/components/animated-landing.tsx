"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  ArrowRight,
  FileText,
  Briefcase,
  MessageSquare,
  BarChart3,
  Sparkles,
  Target,
  Zap,
  Rocket,
  Brain,
  Shield,
} from "lucide-react"
import { ThreeScene } from "./three-scene"

gsap.registerPlugin(ScrollTrigger)

export function AnimatedLanding() {
  const heroRef = useRef<HTMLDivElement>(null)
  const navRef = useRef<HTMLElement>(null)
  const titleRef = useRef<HTMLHeadingElement>(null)
  const subtitleRef = useRef<HTMLParagraphElement>(null)
  const badgeRef = useRef<HTMLDivElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)
  const featuresRef = useRef<HTMLDivElement>(null)
  const stepsRef = useRef<HTMLDivElement>(null)
  const sceneRef = useRef<HTMLDivElement>(null)
  const floatingElementsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Initial hero animations with staggered reveal
      const heroTl = gsap.timeline({ defaults: { ease: "power4.out" } })

      // Nav slides down
      heroTl.fromTo(navRef.current, { y: -100, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8 })

      // Badge pops in with elastic effect
      heroTl.fromTo(
        badgeRef.current,
        { scale: 0, opacity: 0, rotation: -10 },
        { scale: 1, opacity: 1, rotation: 0, duration: 0.6, ease: "elastic.out(1, 0.5)" },
        "-=0.4",
      )

      // Title reveals with split text effect
      heroTl.fromTo(
        titleRef.current,
        { y: 100, opacity: 0, clipPath: "inset(100% 0 0 0)" },
        { y: 0, opacity: 1, clipPath: "inset(0% 0 0 0)", duration: 1 },
        "-=0.3",
      )

      // Subtitle fades up
      heroTl.fromTo(
        subtitleRef.current,
        { y: 50, opacity: 0, filter: "blur(10px)" },
        { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.8 },
        "-=0.5",
      )

      // CTA buttons with stagger
      heroTl.fromTo(
        ctaRef.current?.children || [],
        { y: 30, opacity: 0, scale: 0.9 },
        { y: 0, opacity: 1, scale: 1, duration: 0.5, stagger: 0.15 },
        "-=0.4",
      )

      // 3D scene entrance
      heroTl.fromTo(
        sceneRef.current,
        { scale: 0.8, opacity: 0, x: 100 },
        { scale: 1, opacity: 1, x: 0, duration: 1.2, ease: "power3.out" },
        "-=1",
      )

      // Floating elements continuous animation
      if (floatingElementsRef.current) {
        const floaters = floatingElementsRef.current.querySelectorAll(".floater")
        floaters.forEach((el, i) => {
          gsap.to(el, {
            y: "random(-20, 20)",
            x: "random(-10, 10)",
            rotation: "random(-5, 5)",
            duration: "random(3, 5)",
            repeat: -1,
            yoyo: true,
            ease: "sine.inOut",
            delay: i * 0.2,
          })
        })
      }

      // Feature cards scroll animation
      if (featuresRef.current) {
        const cards = featuresRef.current.querySelectorAll(".feature-card")
        cards.forEach((card, i) => {
          gsap.fromTo(
            card,
            {
              y: 100,
              opacity: 0,
              scale: 0.8,
              rotateY: -15,
            },
            {
              y: 0,
              opacity: 1,
              scale: 1,
              rotateY: 0,
              duration: 0.8,
              ease: "power3.out",
              scrollTrigger: {
                trigger: card,
                start: "top 85%",
                end: "bottom 20%",
                toggleActions: "play none none reverse",
              },
              delay: i * 0.1,
            },
          )
        })
      }

      // Steps section animation with draw effect
      if (stepsRef.current) {
        const steps = stepsRef.current.querySelectorAll(".step-card")
        const connector = stepsRef.current.querySelector(".step-connector")

        if (connector) {
          gsap.fromTo(
            connector,
            { scaleX: 0 },
            {
              scaleX: 1,
              duration: 1.5,
              ease: "power2.inOut",
              scrollTrigger: {
                trigger: stepsRef.current,
                start: "top 70%",
                toggleActions: "play none none reverse",
              },
            },
          )
        }

        steps.forEach((step, i) => {
          gsap.fromTo(
            step,
            { y: 80, opacity: 0, scale: 0.9 },
            {
              y: 0,
              opacity: 1,
              scale: 1,
              duration: 0.7,
              ease: "back.out(1.2)",
              scrollTrigger: {
                trigger: step,
                start: "top 80%",
                toggleActions: "play none none reverse",
              },
              delay: i * 0.2,
            },
          )
        })
      }

      // Parallax effect on hero background
      gsap.to(".hero-gradient", {
        yPercent: 50,
        ease: "none",
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top top",
          end: "bottom top",
          scrub: true,
        },
      })
    }, heroRef)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={heroRef} className="min-h-screen bg-background overflow-hidden">
      {/* Navigation */}
      <nav
        ref={navRef}
        className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/80 backdrop-blur-md"
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary transition-transform group-hover:scale-110 group-hover:rotate-12">
              <Sparkles className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold text-foreground">CareerLaunch</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/auth/login">
              <Button variant="ghost" className="text-muted-foreground hover:text-foreground transition-colors">
                Sign in
              </Button>
            </Link>
            <Link href="/auth/sign-up">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 transition-all hover:scale-105">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen pt-32 pb-20 flex items-center">
        {/* Animated gradient background */}
        <div className="hero-gradient absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />

        {/* Floating decorative elements */}
        <div ref={floatingElementsRef} className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="floater absolute top-20 left-[10%] h-20 w-20 rounded-full bg-primary/10 blur-xl" />
          <div className="floater absolute top-40 right-[15%] h-32 w-32 rounded-full bg-accent/10 blur-2xl" />
          <div className="floater absolute bottom-40 left-[20%] h-24 w-24 rounded-full bg-primary/5 blur-xl" />
          <div className="floater absolute top-60 left-[5%] h-16 w-16 rounded-full bg-accent/5 blur-lg" />
        </div>

        <div className="relative mx-auto max-w-7xl px-6 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-center lg:text-left">
              <div
                ref={badgeRef}
                className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/80 px-4 py-2 text-sm text-muted-foreground backdrop-blur-sm"
              >
                <Zap className="h-4 w-4 text-accent animate-pulse" />
                AI-Powered Career Intelligence
              </div>

              <h1
                ref={titleRef}
                className="text-balance text-5xl font-bold tracking-tight text-foreground md:text-6xl lg:text-7xl"
              >
                Land your dream job with{" "}
                <span className="bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_auto] bg-clip-text text-transparent animate-gradient">
                  AI precision
                </span>
              </h1>

              <p
                ref={subtitleRef}
                className="mt-6 text-pretty text-lg text-muted-foreground md:text-xl max-w-xl mx-auto lg:mx-0"
              >
                Upload your resume, discover perfectly matched opportunities, and prepare for interviews with
                AI-researched insights tailored to your expertise.
              </p>

              <div
                ref={ctaRef}
                className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row lg:justify-start"
              >
                <Link href="/auth/sign-up">
                  <Button
                    size="lg"
                    className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 transition-all hover:scale-105 hover:shadow-lg hover:shadow-primary/25 group"
                  >
                    Start Your Journey
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
                <Link href="#features">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-border text-foreground hover:bg-secondary bg-transparent transition-all hover:scale-105"
                  >
                    See How It Works
                  </Button>
                </Link>
              </div>
            </div>

            {/* Right - Three.js 3D Scene */}
            <div ref={sceneRef} className="relative h-[300px] sm:h-[350px] md:h-[400px] lg:h-[500px]">
              <ThreeScene className="w-full h-full" />
              {/* Glow effect behind 3D scene */}
              <div className="absolute inset-0 -z-10 bg-gradient-to-r from-primary/20 to-accent/20 blur-3xl rounded-full scale-75" />
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground">
          <span className="text-xs uppercase tracking-wider">Scroll to explore</span>
          <div className="h-12 w-6 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-1">
            <div className="h-2 w-1 rounded-full bg-primary animate-bounce" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 relative">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-16 text-center">
            <h2 className="text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
              Everything you need to <span className="text-primary">succeed</span>
            </h2>
            <p className="mt-4 text-muted-foreground text-lg">
              A complete platform that guides you from resume to offer
            </p>
          </div>

          <div ref={featuresRef} className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <FeatureCard
              icon={FileText}
              title="Resume Analysis"
              description="Upload your PDF resume and let AI extract skills, experience, and insights to build your professional profile."
              color="primary"
            />
            <FeatureCard
              icon={Briefcase}
              title="Smart Job Discovery"
              description="AI-powered job matching that finds opportunities aligned with your unique skills and experience level."
              color="accent"
            />
            <FeatureCard
              icon={MessageSquare}
              title="Interview Prep"
              description="Deep AI research generates role-specific technical and behavioral questions with current industry insights."
              color="primary"
            />
            <FeatureCard
              icon={BarChart3}
              title="Progress Dashboard"
              description="Track your job search journey with visual analytics, skill assessments, and actionable recommendations."
              color="accent"
            />
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="border-t border-border bg-card/50 py-24 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:24px_24px]" />

        <div className="relative mx-auto max-w-7xl px-6">
          <div className="mb-16 text-center">
            <h2 className="text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">How it works</h2>
            <p className="mt-4 text-muted-foreground text-lg">Three simple steps to accelerate your career</p>
          </div>

          <div ref={stepsRef} className="relative">
            {/* Connector line */}
            <div className="step-connector absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-accent to-primary hidden md:block origin-left" />

            <div className="grid gap-12 md:grid-cols-3 relative">
              <StepCard
                number="01"
                icon={Rocket}
                title="Upload Resume"
                description="Upload your PDF resume and our AI extracts and structures your skills, experience, education, and projects."
              />
              <StepCard
                number="02"
                icon={Brain}
                title="Discover Jobs"
                description="AI scans job sources to find opportunities matching your profile, ranking them by compatibility with clear explanations."
              />
              <StepCard
                number="03"
                icon={Shield}
                title="Prepare & Apply"
                description="Get AI-researched interview prep with technology-specific questions, company insights, and best practices."
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary/20 via-background to-accent/20 p-12 text-center border border-border">
            {/* Animated background */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(59,130,246,0.1),transparent_50%),radial-gradient(circle_at_70%_70%,rgba(34,211,238,0.1),transparent_50%)]" />

            <div className="relative">
              <Target className="mx-auto mb-6 h-16 w-16 text-primary animate-pulse" />
              <h2 className="text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
                Ready to launch your career?
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-muted-foreground text-lg">
                Join thousands of professionals using AI to find better opportunities and prepare smarter for
                interviews.
              </p>
              <Link href="/auth/sign-up">
                <Button
                  size="lg"
                  className="mt-8 gap-2 bg-primary text-primary-foreground hover:bg-primary/90 transition-all hover:scale-105 hover:shadow-lg hover:shadow-primary/25 group"
                >
                  Get Started Free
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <Sparkles className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-lg font-semibold text-foreground">CareerLaunch</span>
            </div>
            <p className="text-sm text-muted-foreground">Built with AI to help you succeed</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({
  icon: Icon,
  title,
  description,
  color,
}: {
  icon: React.ElementType
  title: string
  description: string
  color: "primary" | "accent"
}) {
  return (
    <div className="feature-card group rounded-2xl border border-border bg-card p-6 transition-all duration-500 hover:border-primary/50 hover:bg-card/80 hover:shadow-xl hover:shadow-primary/5 hover:-translate-y-2">
      <div
        className={`mb-4 flex h-14 w-14 items-center justify-center rounded-xl ${color === "primary" ? "bg-primary/10 text-primary group-hover:bg-primary" : "bg-accent/10 text-accent group-hover:bg-accent"} transition-all duration-300 group-hover:text-background group-hover:scale-110 group-hover:rotate-3`}
      >
        <Icon className="h-7 w-7" />
      </div>
      <h3 className="mb-2 text-xl font-semibold text-foreground">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  )
}

function StepCard({
  number,
  icon: Icon,
  title,
  description,
}: {
  number: string
  icon: React.ElementType
  title: string
  description: string
}) {
  return (
    <div className="step-card relative text-center bg-card border border-border rounded-2xl p-8 transition-all hover:shadow-xl hover:shadow-primary/5">
      <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full border-2 border-primary bg-primary/10 relative">
        <Icon className="h-8 w-8 text-primary" />
        <span className="absolute -top-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
          {number}
        </span>
      </div>
      <h3 className="mb-3 text-xl font-semibold text-foreground">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  )
}

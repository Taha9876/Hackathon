"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Upload, FileText, AlertCircle, Loader2 } from "lucide-react"
import type { ParsedResume } from "@/lib/types"

interface ResumeUploadProps {
  onSuccess: (resume: ParsedResume) => void
}

export function ResumeUpload({ onSuccess }: ResumeUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      const file = acceptedFiles[0]
      if (!file) return

      if (file.type !== "application/pdf") {
        setError("Please upload a PDF file")
        return
      }

      setFileName(file.name)
      setIsUploading(true)
      setError(null)
      setProgress(10)

      try {
        const formData = new FormData()
        formData.append("file", file)

        setProgress(30)

        const response = await fetch("/api/parse-resume", {
          method: "POST",
          body: formData,
        })

        setProgress(70)

        const result = await response.json()

        if (!response.ok) {
          throw new Error(result.error || "Failed to parse resume")
        }

        if (!result.parsed) {
          throw new Error("No parsed data received from API")
        }

        setProgress(100)
        onSuccess(result.parsed)
      } catch (err) {
        console.error("Resume upload error:", err)
        setError(err instanceof Error ? err.message : "An error occurred")
        setProgress(0)
      } finally {
        setIsUploading(false)
      }
    },
    [onSuccess],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
    },
    maxFiles: 1,
    disabled: isUploading,
  })

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <FileText className="h-5 w-5 text-primary" />
          Upload Your Resume
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Upload a PDF resume and our AI will extract your skills, experience, and qualifications
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div
          {...getRootProps()}
          className={`
            relative cursor-pointer rounded-xl border-2 border-dashed p-8 text-center transition-all
            ${isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}
            ${isUploading ? "pointer-events-none opacity-60" : ""}
          `}
        >
          <input {...getInputProps()} />

          {isUploading ? (
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="h-12 w-12 animate-spin text-primary" />
              <div className="space-y-2">
                <p className="text-sm font-medium text-foreground">Analyzing {fileName}...</p>
                <p className="text-xs text-muted-foreground">Our AI is extracting your skills and experience</p>
              </div>
              <Progress value={progress} className="h-2 w-48" />
            </div>
          ) : error ? (
            <div className="flex flex-col items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10">
                <AlertCircle className="h-6 w-6 text-destructive" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-foreground">{error}</p>
                <p className="text-xs text-muted-foreground">Click to try again</p>
              </div>
            </div>
          ) : isDragActive ? (
            <div className="flex flex-col items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground">Drop your resume here</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <Upload className="h-6 w-6 text-muted-foreground" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-foreground">Drag and drop your resume</p>
                <p className="text-xs text-muted-foreground">or click to browse (PDF only)</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-border text-foreground hover:bg-secondary bg-transparent"
              >
                Select File
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import { useEffect, useRef, useState } from "react"
import * as THREE from "three"

export function ThreeScene({ className }: { className?: string }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    if (!isMounted || !containerRef.current) return

    const container = containerRef.current
    const width = container.clientWidth
    const height = container.clientHeight

    if (width < 100 || height < 100) return

    // Scene setup
    const scene = new THREE.Scene()

    // Camera
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000)
    camera.position.z = 5

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setSize(width, height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setClearColor(0x000000, 0)
    container.appendChild(renderer.domElement)
    rendererRef.current = renderer

    // Create floating geometric shapes
    const shapes: THREE.Mesh[] = []

    const scaleFactor = Math.min(width, height) / 500

    // Main central sphere with gradient-like material
    const sphereGeometry = new THREE.IcosahedronGeometry(1.5 * scaleFactor, 1)
    const sphereMaterial = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      metalness: 0.7,
      roughness: 0.2,
      wireframe: false,
    })
    const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial)
    scene.add(sphere)
    shapes.push(sphere)

    // Outer ring torus
    const torusGeometry = new THREE.TorusGeometry(2.2 * scaleFactor, 0.05 * scaleFactor, 16, 100)
    const torusMaterial = new THREE.MeshStandardMaterial({
      color: 0x22d3ee,
      metalness: 0.8,
      roughness: 0.1,
    })
    const torus = new THREE.Mesh(torusGeometry, torusMaterial)
    torus.rotation.x = Math.PI / 2
    scene.add(torus)
    shapes.push(torus)

    // Second ring
    const torus2Geometry = new THREE.TorusGeometry(2.5 * scaleFactor, 0.03 * scaleFactor, 16, 100)
    const torus2Material = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      metalness: 0.9,
      roughness: 0.1,
      transparent: true,
      opacity: 0.6,
    })
    const torus2 = new THREE.Mesh(torus2Geometry, torus2Material)
    torus2.rotation.x = Math.PI / 3
    torus2.rotation.y = Math.PI / 4
    scene.add(torus2)
    shapes.push(torus2)

    // Floating smaller shapes - scaled positions
    const smallShapePositions = [
      { x: 3 * scaleFactor, y: 1.5 * scaleFactor, z: -1, scale: 0.3 * scaleFactor, color: 0x22d3ee },
      { x: -2.5 * scaleFactor, y: -1 * scaleFactor, z: 0.5, scale: 0.25 * scaleFactor, color: 0x3b82f6 },
      { x: 2 * scaleFactor, y: -1.8 * scaleFactor, z: 1, scale: 0.2 * scaleFactor, color: 0x22d3ee },
      { x: -3 * scaleFactor, y: 1 * scaleFactor, z: -0.5, scale: 0.35 * scaleFactor, color: 0x3b82f6 },
      { x: 0, y: 2.5 * scaleFactor, z: 0.5, scale: 0.15 * scaleFactor, color: 0x22d3ee },
    ]

    smallShapePositions.forEach((pos, i) => {
      const geometry = i % 2 === 0 ? new THREE.OctahedronGeometry(pos.scale) : new THREE.TetrahedronGeometry(pos.scale)
      const material = new THREE.MeshStandardMaterial({
        color: pos.color,
        metalness: 0.6,
        roughness: 0.3,
      })
      const mesh = new THREE.Mesh(geometry, material)
      mesh.position.set(pos.x, pos.y, pos.z)
      scene.add(mesh)
      shapes.push(mesh)
    })

    // Particle system - fewer particles on smaller screens
    const particlesGeometry = new THREE.BufferGeometry()
    const particleCount = Math.floor(200 * scaleFactor)
    const posArray = new Float32Array(particleCount * 3)

    for (let i = 0; i < particleCount * 3; i++) {
      posArray[i] = (Math.random() - 0.5) * 10 * scaleFactor
    }

    particlesGeometry.setAttribute("position", new THREE.BufferAttribute(posArray, 3))
    const particlesMaterial = new THREE.PointsMaterial({
      size: 0.02 * scaleFactor,
      color: 0x22d3ee,
      transparent: true,
      opacity: 0.6,
    })
    const particles = new THREE.Points(particlesGeometry, particlesMaterial)
    scene.add(particles)

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4)
    scene.add(ambientLight)

    const pointLight1 = new THREE.PointLight(0x3b82f6, 2, 10)
    pointLight1.position.set(3, 3, 3)
    scene.add(pointLight1)

    const pointLight2 = new THREE.PointLight(0x22d3ee, 2, 10)
    pointLight2.position.set(-3, -3, 3)
    scene.add(pointLight2)

    // Mouse movement tracking
    let mouseX = 0
    let mouseY = 0

    const handleMouseMove = (event: MouseEvent) => {
      mouseX = (event.clientX / window.innerWidth) * 2 - 1
      mouseY = -(event.clientY / window.innerHeight) * 2 + 1
    }

    const handleTouchMove = (event: TouchEvent) => {
      if (event.touches.length > 0) {
        mouseX = (event.touches[0].clientX / window.innerWidth) * 2 - 1
        mouseY = -(event.touches[0].clientY / window.innerHeight) * 2 + 1
      }
    }

    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("touchmove", handleTouchMove, { passive: true })

    // Animation loop
    let animationId: number
    let time = 0
    const animate = () => {
      time += 0.01

      // Rotate main sphere
      sphere.rotation.x += 0.002
      sphere.rotation.y += 0.003

      // Rotate rings
      torus.rotation.z += 0.005
      torus2.rotation.z -= 0.003
      torus2.rotation.x += 0.002

      // Animate small shapes
      shapes.slice(3).forEach((shape, i) => {
        shape.rotation.x += 0.01 * (i + 1) * 0.5
        shape.rotation.y += 0.01 * (i + 1) * 0.5
        shape.position.y += Math.sin(time + i) * 0.003
      })

      // Rotate particles
      particles.rotation.y += 0.0005

      // Camera movement based on mouse
      camera.position.x += (mouseX * 0.5 - camera.position.x) * 0.02
      camera.position.y += (mouseY * 0.5 - camera.position.y) * 0.02
      camera.lookAt(scene.position)

      renderer.render(scene, camera)
      animationId = requestAnimationFrame(animate)
    }

    animate()

    // Handle resize
    const handleResize = () => {
      const newWidth = container.clientWidth
      const newHeight = container.clientHeight

      if (newWidth < 100 || newHeight < 100) return

      camera.aspect = newWidth / newHeight
      camera.updateProjectionMatrix()

      renderer.setSize(newWidth, newHeight)
    }

    window.addEventListener("resize", handleResize)

    // Cleanup
    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("touchmove", handleTouchMove)
      window.removeEventListener("resize", handleResize)
      cancelAnimationFrame(animationId)
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement)
      }
      renderer.dispose()
    }
  }, [isMounted])

  if (!isMounted) {
    return (
      <div className={`${className} flex items-center justify-center`}>
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  return <div ref={containerRef} className={className} />
}

import { createClient } from "@/lib/supabase/server"

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const updates = await req.json()

    const { data, error } = await supabase
      .from("job_matches")
      .update(updates)
      .eq("id", id)
      .eq("user_id", user.id)
      .select()
      .single()

    if (error) {
      return Response.json({ error: "Failed to update job" }, { status: 500 })
    }

    return Response.json({ success: true, job: data })
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "An error occurred" }, { status: 500 })
  }
}

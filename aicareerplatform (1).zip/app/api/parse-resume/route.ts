import { createClient } from "@/lib/supabase/server"
import { generateText } from "ai"
import { createGroq } from "@ai-sdk/groq"
import { extractText, getDocumentProxy } from "unpdf"

const groq = createGroq({
  apiKey: process.env.GROQ_API_KEY,
})

async function extractTextFromPDF(buffer: Buffer): Promise<string> {
  console.log("[v0] Attempting PDF text extraction with unpdf...")

  try {
    const uint8Array = new Uint8Array(buffer)
    const pdf = await getDocumentProxy(uint8Array)
    const { text } = await extractText(pdf, { mergePages: true })

    console.log("[v0] unpdf extracted", text.length, "characters")

    // Clean up the text
    const cleanedText = text.replace(/\s+/g, " ").replace(/\n+/g, "\n").trim()

    if (cleanedText.length > 50) {
      return cleanedText
    }

    throw new Error("Insufficient text extracted from PDF")
  } catch (error) {
    console.log("[v0] unpdf extraction error:", error)

    console.log("[v0] Trying enhanced fallback text extraction...")

    const text = buffer.toString("latin1")
    const extractedParts: string[] = []

    // Extract text from PDF text streams (BT...ET blocks)
    const streamPattern = /BT\s*([\s\S]*?)\s*ET/g
    let match
    while ((match = streamPattern.exec(text)) !== null) {
      const streamContent = match[1]
      // Extract text from Tj and TJ operators
      const tjMatches = streamContent.match(/$$([^)]+)$$\s*Tj/g) || []
      const tjTexts = tjMatches.map((m) => {
        const content = m.match(/$$([^)]+)$$/)?.[1] || ""
        return content.replace(/\\([0-9]{3})/g, (_, octal) => String.fromCharCode(Number.parseInt(octal, 8)))
      })
      extractedParts.push(...tjTexts)

      // Also extract from TJ arrays
      const tjArrayMatches = streamContent.match(/\[(.*?)\]\s*TJ/g) || []
      for (const tjArray of tjArrayMatches) {
        const innerTexts = tjArray.match(/$$([^)]+)$$/g) || []
        const texts = innerTexts.map((t) => {
          const content = t.slice(1, -1)
          return content.replace(/\\([0-9]{3})/g, (_, octal) => String.fromCharCode(Number.parseInt(octal, 8)))
        })
        extractedParts.push(texts.join(""))
      }
    }

    // Also try to find text in parentheses outside streams
    const parenMatches = text.match(/$$([A-Za-z0-9@.\-_+\s,;:'"/!?&]+)$$/g) || []
    const parenTexts = parenMatches.map((m) => m.slice(1, -1)).filter((s) => s.length > 2 && /[a-zA-Z]{2,}/.test(s))
    extractedParts.push(...parenTexts)

    const combinedText = extractedParts
      .filter((s) => s.trim().length > 0)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim()

    console.log("[v0] Fallback extracted", combinedText.length, "characters")

    if (combinedText.length > 100) {
      return combinedText
    }

    throw new Error(
      "Could not extract readable text from PDF. Please ensure the PDF contains selectable text, not scanned images.",
    )
  }
}

function parseJSONFromText(text: string): Record<string, unknown> {
  // Try to extract JSON from markdown code blocks or raw JSON
  const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/) || text.match(/(\{[\s\S]*\})/)
  if (jsonMatch) {
    return JSON.parse(jsonMatch[1].trim())
  }
  return JSON.parse(text)
}

export async function POST(req: Request) {
  try {
    console.log("[v0] Starting resume parse request...")

    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      console.log("[v0] Unauthorized - no user")
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    console.log("[v0] User authenticated:", user.id)

    const formData = await req.formData()
    const file = formData.get("file") as File

    if (!file) {
      return Response.json({ error: "No file provided" }, { status: 400 })
    }

    console.log("[v0] File received:", file.name, "Type:", file.type, "Size:", file.size)

    if (file.type !== "application/pdf") {
      return Response.json({ error: "Only PDF files are supported" }, { status: 400 })
    }

    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    console.log("[v0] Buffer created, size:", buffer.length)

    const rawText = await extractTextFromPDF(buffer)

    if (!rawText || rawText.trim().length < 50) {
      console.log("[v0] Insufficient text extracted:", rawText?.length || 0)
      return Response.json(
        { error: "Could not extract text from PDF. Please ensure the PDF contains selectable text." },
        { status: 400 },
      )
    }

    console.log("[v0] Text extracted successfully, length:", rawText.length)
    console.log("[v0] Sample extracted text:", rawText.substring(0, 500))
    console.log("[v0] Starting AI analysis with Groq...")

    const truncatedText = rawText.length > 8000 ? rawText.substring(0, 8000) + "..." : rawText

    const { text: aiResponse } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: `You are an expert resume parser. Analyze the following resume text and extract all relevant information into a structured JSON format.

IMPORTANT: Extract ALL information you can find. Look carefully for:
- Full name (usually at the top)
- Contact details (email, phone, location, LinkedIn, GitHub, portfolio links)
- Professional summary or objective
- ALL skills mentioned (programming languages, frameworks, tools, soft skills)
- ALL work experience with dates, company names, job titles, and descriptions
- ALL education history with degrees, institutions, and dates
- ALL projects with descriptions and technologies used

Return ONLY valid JSON (no markdown, no explanation) with this exact structure:
{
  "fullName": "string - candidate's full name",
  "email": "string or null - email address",
  "phone": "string or null - phone number",
  "location": "string or null - location/city",
  "linkedin": "string or null - LinkedIn URL",
  "github": "string or null - GitHub URL",
  "portfolio": "string or null - portfolio/website URL",
  "summary": "string - 2-3 sentence professional summary based on the resume content",
  "skills": [
    {
      "name": "string - skill name",
      "category": "string - one of: Programming Languages, Frameworks, Databases, Cloud & DevOps, Tools, Soft Skills",
      "proficiency": "beginner|intermediate|advanced|expert (infer from context)"
    }
  ],
  "experience": [
    {
      "title": "string - job title",
      "company": "string - company name",
      "location": "string or null",
      "startDate": "string - start date",
      "endDate": "string or null - end date",
      "current": boolean,
      "description": "string - role description",
      "highlights": ["string - key achievements"]
    }
  ],
  "education": [
    {
      "degree": "string - degree name",
      "institution": "string - school name",
      "location": "string or null",
      "graduationDate": "string",
      "gpa": "string or null",
      "highlights": ["string - coursework, honors"]
    }
  ],
  "projects": [
    {
      "name": "string - project name",
      "description": "string - project description",
      "technologies": ["string - technologies used"],
      "url": "string or null",
      "highlights": ["string - key features"]
    }
  ],
  "expertiseAreas": ["string - top 3-5 areas of expertise"],
  "yearsOfExperience": number
}

Resume Text:
${truncatedText}`,
    })

    console.log("[v0] AI response received, parsing JSON...")
    console.log("[v0] AI raw response length:", aiResponse.length)

    const parsedResume = parseJSONFromText(aiResponse)

    console.log("[v0] AI analysis complete, parsed name:", parsedResume.fullName)
    console.log("[v0] Parsed skills count:", Array.isArray(parsedResume.skills) ? parsedResume.skills.length : 0)
    console.log(
      "[v0] Parsed experience count:",
      Array.isArray(parsedResume.experience) ? parsedResume.experience.length : 0,
    )

    // Try upsert first
    const { data: existingResume } = await supabase.from("resumes").select("id").eq("user_id", user.id).maybeSingle()

    let resumeRecord
    if (existingResume) {
      const { data, error } = await supabase
        .from("resumes")
        .update({
          file_name: file.name,
          raw_text: rawText.substring(0, 50000),
          parsed_data: parsedResume,
          skills: parsedResume.skills,
          experience: parsedResume.experience,
          education: parsedResume.education,
          projects: parsedResume.projects,
          summary: parsedResume.summary,
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", user.id)
        .select()
        .single()

      if (error) throw error
      resumeRecord = data
    } else {
      const { data, error } = await supabase
        .from("resumes")
        .insert({
          user_id: user.id,
          file_name: file.name,
          raw_text: rawText.substring(0, 50000),
          parsed_data: parsedResume,
          skills: parsedResume.skills,
          experience: parsedResume.experience,
          education: parsedResume.education,
          projects: parsedResume.projects,
          summary: parsedResume.summary,
        })
        .select()
        .single()

      if (error) throw error
      resumeRecord = data
    }

    console.log("[v0] Resume saved successfully")

    return Response.json({
      success: true,
      resume: resumeRecord,
      parsed: parsedResume,
    })
  } catch (error) {
    console.error("[v0] Resume parsing error:", error)
    return Response.json({ error: error instanceof Error ? error.message : "Failed to parse resume" }, { status: 500 })
  }
}

import { createClient } from "@/lib/supabase/server"
import { generateText } from "ai"
import { createGroq } from "@ai-sdk/groq"

const groq = createGroq({
  apiKey: process.env.GROQ_API_KEY,
})

function parseJSONFromText(text: string): Record<string, unknown> {
  const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/) || text.match(/(\{[\s\S]*\})/)
  if (jsonMatch) {
    return JSON.parse(jsonMatch[1].trim())
  }
  return JSON.parse(text)
}

interface PrepData {
  companyInsights: {
    overview: string
    culture: string
    techStack: string[]
    interviewProcess: string
    recentNews: string[]
  }
  technicalQuestions: Array<{
    question: string
    topic: string
    difficulty: string
    hints: string[]
    keyPoints: string[]
  }>
  behavioralQuestions: Array<{
    question: string
    category: string
    starExample: {
      situation: string
      task: string
      action: string
      result: string
    }
  }>
  tips: string[]
}

export async function POST(req: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { companyName, role, technologies } = await req.json()

    if (!companyName || !role) {
      return Response.json({ error: "Company name and role are required" }, { status: 400 })
    }

    const { data: resumeData } = await supabase.from("resumes").select("parsed_data").eq("user_id", user.id).single()

    const userSkills = resumeData?.parsed_data?.skills?.map((s: { name: string }) => s.name) || []
    const userExperience = resumeData?.parsed_data?.experience || []

    const { text: aiResponse } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: `You are an expert career coach and technical interviewer. Generate comprehensive interview preparation materials.

Return ONLY valid JSON (no markdown, no explanation) with this exact structure:
{
  "companyInsights": {
    "overview": "string - brief company overview",
    "culture": "string - company culture and values",
    "techStack": ["string - technologies used"],
    "interviewProcess": "string - typical interview process",
    "recentNews": ["string - recent news/achievements"]
  },
  "technicalQuestions": [
    {
      "question": "string - technical question",
      "topic": "string - topic category",
      "difficulty": "easy|medium|hard",
      "hints": ["string - hints"],
      "keyPoints": ["string - key points interviewers look for"]
    }
  ],
  "behavioralQuestions": [
    {
      "question": "string - behavioral question",
      "category": "string - category like Leadership, Teamwork",
      "starExample": {
        "situation": "string - example situation",
        "task": "string - task faced",
        "action": "string - actions taken",
        "result": "string - results achieved"
      }
    }
  ],
  "tips": ["string - 10-15 preparation tips"]
}

INTERVIEW DETAILS:
- Company: ${companyName}
- Role: ${role}
- Technologies: ${technologies?.join(", ") || "Not specified"}

CANDIDATE BACKGROUND:
- Skills: ${userSkills.join(", ")}
- Recent Experience: ${userExperience
        .slice(0, 2)
        .map((e: { title: string; company: string }) => `${e.title} at ${e.company}`)
        .join(", ")}

Generate 15-20 technical questions and 8-10 behavioral questions with STAR examples.`,
    })

    const prepData = parseJSONFromText(aiResponse) as PrepData

    const { data: prepRecord, error: insertError } = await supabase
      .from("interview_preps")
      .insert({
        user_id: user.id,
        company_name: companyName,
        role: role,
        technologies: technologies || [],
        research_data: prepData.companyInsights,
        technical_questions: prepData.technicalQuestions,
        behavioral_questions: prepData.behavioralQuestions,
        company_insights: prepData.companyInsights,
        tips: prepData.tips,
        status: "completed",
      })
      .select()
      .single()

    if (insertError) {
      console.error("Database error:", insertError)
    }

    return Response.json({
      success: true,
      prep: {
        id: prepRecord?.id,
        companyName,
        role,
        technologies,
        ...prepData,
        status: "completed",
        createdAt: prepRecord?.created_at || new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("Interview prep error:", error)
    return Response.json(
      { error: error instanceof Error ? error.message : "Failed to generate interview prep" },
      { status: 500 },
    )
  }
}

export async function GET(req: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const url = new URL(req.url)
    const id = url.searchParams.get("id")

    if (id) {
      const { data } = await supabase.from("interview_preps").select("*").eq("id", id).eq("user_id", user.id).single()

      if (!data) {
        return Response.json({ error: "Not found" }, { status: 404 })
      }

      return Response.json({
        prep: {
          id: data.id,
          companyName: data.company_name,
          role: data.role,
          technologies: data.technologies,
          companyInsights: data.company_insights,
          technicalQuestions: data.technical_questions,
          behavioralQuestions: data.behavioral_questions,
          tips: data.tips,
          status: data.status,
          createdAt: data.created_at,
        },
      })
    }

    const { data: preps } = await supabase
      .from("interview_preps")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    return Response.json({
      preps: preps?.map((p) => ({
        id: p.id,
        companyName: p.company_name,
        role: p.role,
        technologies: p.technologies,
        status: p.status,
        createdAt: p.created_at,
      })),
    })
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "An error occurred" }, { status: 500 })
  }
}

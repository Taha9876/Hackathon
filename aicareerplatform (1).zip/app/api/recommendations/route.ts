import { createClient } from "@/lib/supabase/server"
import { generateText } from "ai"
import { createGroq } from "@ai-sdk/groq"

const groq = createGroq({
  apiKey: process.env.GROQ_API_KEY,
})

function parseJSONFromText(text: string): Record<string, unknown> {
  const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/) || text.match(/(\{[\s\S]*\})/)
  if (jsonMatch) {
    return JSON.parse(jsonMatch[1].trim())
  }
  return JSON.parse(text)
}

export async function GET(req: Request) {
  try {
    console.log("[v0] Generating recommendations...")

    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: resumeData } = await supabase.from("resumes").select("*").eq("user_id", user.id).single()

    if (!resumeData?.parsed_data) {
      return Response.json({ error: "Please upload your resume first" }, { status: 400 })
    }

    const resume = resumeData.parsed_data

    const { data: jobsData } = await supabase
      .from("job_matches")
      .select("*")
      .eq("user_id", user.id)
      .order("compatibility_score", { ascending: false })
      .limit(10)

    const jobContext = jobsData?.length
      ? `Recent job matches average ${Math.round(jobsData.reduce((a, j) => a + j.compatibility_score, 0) / jobsData.length)}% compatibility. Top matched skills: ${[...new Set(jobsData.flatMap((j) => j.skills_matched || []))].slice(0, 10).join(", ")}`
      : "No job matches yet."

    console.log("[v0] Calling Groq for recommendations...")

    const { text: aiResponse } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: `You are an expert career advisor. Analyze this candidate's profile and provide comprehensive career recommendations.

Return ONLY valid JSON (no markdown, no explanation) with this exact structure:
{
  "careerInsights": {
    "currentStrengths": ["string - top 5 strengths"],
    "areasForImprovement": ["string - top 5 areas to improve"],
    "marketReadiness": number 0-100,
    "uniqueSellingPoints": ["string - what makes them stand out"]
  },
  "skillRecommendations": [
    {
      "skill": "string - skill to learn",
      "reason": "string - why valuable",
      "priority": "high|medium|low",
      "resources": ["string - learning resources"]
    }
  ],
  "careerPaths": [
    {
      "title": "string - career path/role",
      "fit": number 0-100,
      "requirements": ["string - what's needed"],
      "timeline": "string - time to transition"
    }
  ],
  "resumeTips": [
    {
      "section": "string - resume section",
      "tip": "string - improvement suggestion",
      "impact": "high|medium|low"
    }
  ],
  "interviewFocus": ["string - key areas to prepare"],
  "salaryInsights": {
    "estimatedRange": "string - salary range",
    "factors": ["string - factors to increase salary"]
  }
}

CANDIDATE PROFILE:
- Name: ${resume.fullName}
- Years of Experience: ${resume.yearsOfExperience}
- Summary: ${resume.summary}
- Key Skills: ${resume.skills?.map((s: { name: string; proficiency: string }) => `${s.name} (${s.proficiency})`).join(", ")}
- Expertise Areas: ${resume.expertiseAreas?.join(", ")}

WORK EXPERIENCE:
${resume.experience
  ?.map(
    (exp: { title: string; company: string; description: string; highlights: string[] }) =>
      `- ${exp.title} at ${exp.company}: ${exp.description}\n  Highlights: ${exp.highlights?.join("; ")}`,
  )
  .join("\n")}

EDUCATION:
${resume.education?.map((edu: { degree: string; institution: string }) => `- ${edu.degree} from ${edu.institution}`).join("\n")}

PROJECTS:
${resume.projects?.map((p: { name: string; description: string; technologies: string[] }) => `- ${p.name}: ${p.description} (${p.technologies?.join(", ")})`).join("\n")}

JOB SEARCH CONTEXT:
${jobContext}

Provide specific, actionable recommendations.`,
    })

    const recommendations = parseJSONFromText(aiResponse)

    console.log("[v0] Recommendations generated successfully")

    return Response.json({
      success: true,
      recommendations,
    })
  } catch (error) {
    console.error("[v0] Recommendations error:", error)
    return Response.json(
      { error: error instanceof Error ? error.message : "Failed to generate recommendations" },
      { status: 500 },
    )
  }
}

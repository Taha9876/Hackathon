import { createClient } from "@/lib/supabase/server"
import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

function parseJSONFromText(text: string): Record<string, unknown> {
  const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/) || text.match(/(\{[\s\S]*\})/)
  if (jsonMatch) {
    return JSON.parse(jsonMatch[1].trim())
  }
  return JSON.parse(text)
}

async function fetchRealJobs(): Promise<any[]> {
  const allJobs: any[] = []

  // Fetch from Remotive API (real remote jobs)
  try {
    const remotiveRes = await fetch("https://remotive.com/api/remote-jobs?limit=30", {
      headers: { Accept: "application/json" },
      next: { revalidate: 3600 },
    })
    if (remotiveRes.ok) {
      const data = await remotiveRes.json()
      const jobs = (data.jobs || []).map((job: any) => ({
        title: job.title,
        company: job.company_name,
        location: job.candidate_required_location || "Remote",
        description: job.description?.replace(/<[^>]*>/g, "").slice(0, 500) || "",
        url: job.url,
        source: "Remotive",
        tags: job.tags || [],
        category: job.category,
        jobType: job.job_type?.toLowerCase() || "full-time",
        salary: job.salary || null,
        postedDate: job.publication_date,
      }))
      allJobs.push(...jobs)
    }
  } catch (e) {
    console.log("[v0] Remotive fetch error:", e)
  }

  // Fetch from Arbeitnow API
  try {
    const arbeitnowRes = await fetch("https://www.arbeitnow.com/api/job-board-api", {
      headers: { Accept: "application/json" },
      next: { revalidate: 3600 },
    })
    if (arbeitnowRes.ok) {
      const data = await arbeitnowRes.json()
      const jobs = (data.data || []).slice(0, 30).map((job: any) => ({
        title: job.title,
        company: job.company_name,
        location: job.location || (job.remote ? "Remote" : "On-site"),
        description: job.description?.replace(/<[^>]*>/g, "").slice(0, 500) || "",
        url: job.url,
        source: "Arbeitnow",
        tags: job.tags || [],
        category: job.tags?.[0] || "General",
        jobType: job.job_types?.[0]?.toLowerCase() || "full-time",
        salary: null,
        postedDate: job.created_at ? new Date(job.created_at * 1000).toISOString() : null,
      }))
      allJobs.push(...jobs)
    }
  } catch (e) {
    console.log("[v0] Arbeitnow fetch error:", e)
  }

  return allJobs
}

export async function POST(req: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: resumeData } = await supabase.from("resumes").select("*").eq("user_id", user.id).maybeSingle()

    if (!resumeData?.parsed_data) {
      return Response.json({ error: "Please upload your resume first" }, { status: 400 })
    }

    const resume = resumeData.parsed_data
    const { filters } = await req.json()

    const skills = resume.skills?.map((s: { name: string }) => s.name).slice(0, 10) || []
    const expertiseAreas = resume.expertiseAreas || []
    const recentRole = resume.experience?.[0]?.title || ""

    const locationFilter = filters?.location || resume.location || "Remote"
    const jobTypeFilter = filters?.jobType || "full-time"
    const experienceLevel =
      resume.yearsOfExperience < 2
        ? "entry"
        : resume.yearsOfExperience < 5
          ? "mid"
          : resume.yearsOfExperience < 8
            ? "senior"
            : "lead"

    const realJobs = await fetchRealJobs()

    const { text: aiResponse } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: `You are a job matching AI. Analyze these real job listings and match them to the candidate's profile. Also generate additional high-quality job matches from major tech companies.

CANDIDATE PROFILE:
- Name: ${resume.fullName}
- Years of Experience: ${resume.yearsOfExperience}
- Experience Level: ${experienceLevel}
- Key Skills: ${skills.join(", ")}
- Expertise Areas: ${expertiseAreas.join(", ")}
- Most Recent Role: ${recentRole}
- Preferred Location: ${locationFilter}
- Summary: ${resume.summary}

REAL JOB LISTINGS FROM JOB BOARDS:
${JSON.stringify(realJobs.slice(0, 20), null, 2)}

Return ONLY valid JSON (no markdown code blocks, no explanation) with this structure:
{
  "jobs": [
    {
      "title": "string",
      "company": "string - use real company name from listings above OR real tech companies",
      "location": "string",
      "description": "string - 2-3 sentences",
      "requirements": ["5-7 requirements"],
      "qualifications": ["4-6 qualifications"],
      "responsibilities": ["5-7 responsibilities"],
      "url": "string - use real URL from listings above or realistic careers URL",
      "source": "string - Remotive, Arbeitnow, LinkedIn, or Company Careers",
      "compatibilityScore": number 0-100,
      "matchReasons": ["4-6 specific match reasons"],
      "skillsMatched": ["matched skills"],
      "skillsGap": ["skills to develop"],
      "salary": { "min": number, "max": number, "currency": "USD", "period": "yearly" },
      "jobType": "full-time",
      "experienceLevel": "${experienceLevel}",
      "postedDate": "ISO date string",
      "benefits": ["4-6 benefits"],
      "companyInfo": { "size": "string", "industry": "string", "founded": "year", "website": "url" }
    }
  ]
}

IMPORTANT:
1. Include ALL relevant real jobs from the listings above with match scores
2. Add 5-8 additional AI-generated jobs from companies like Google, Microsoft, Amazon, Meta, Apple, Netflix, Stripe, Airbnb, etc.
3. Ensure compatibility scores accurately reflect skill overlap
4. Total should be 12-18 jobs, sorted by compatibility score`,
    })

    const jobResults = parseJSONFromText(aiResponse) as { jobs: any[] }

    const jobsToInsert = jobResults.jobs.map((job) => ({
      user_id: user.id,
      title: job.title,
      company: job.company,
      location: job.location,
      description: job.description,
      requirements: job.requirements || [],
      qualifications: job.qualifications || [],
      responsibilities: job.responsibilities || [],
      url: job.url,
      source: job.source,
      compatibility_score: job.compatibilityScore,
      match_reasons: job.matchReasons,
      skills_matched: job.skillsMatched,
      skills_gap: job.skillsGap || [],
      status: "new",
      saved: false,
      applied: false,
      salary: job.salary,
      job_type: job.jobType || "full-time",
      experience_level: job.experienceLevel || experienceLevel,
      posted_date: job.postedDate ? new Date(job.postedDate).toISOString() : null,
      benefits: job.benefits || [],
      company_info: job.companyInfo,
    }))

    await supabase.from("job_matches").delete().eq("user_id", user.id)

    const { error: insertError } = await supabase.from("job_matches").insert(jobsToInsert)

    if (insertError) {
      console.error("[v0] Database insert error:", insertError)
    }

    return Response.json({
      success: true,
      jobs: jobResults.jobs,
      totalFound: jobResults.jobs.length,
      realJobsScraped: realJobs.length,
    })
  } catch (error) {
    console.error("[v0] Job discovery error:", error)
    return Response.json({ error: error instanceof Error ? error.message : "Failed to discover jobs" }, { status: 500 })
  }
}

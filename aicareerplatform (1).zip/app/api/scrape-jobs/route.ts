import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

// Job sources - using public APIs that allow scraping
const JOB_SOURCES = [
  {
    name: "Remotive",
    url: "https://remotive.com/api/remote-jobs",
    type: "api",
  },
  {
    name: "Arbeitnow",
    url: "https://www.arbeitnow.com/api/job-board-api",
    type: "api",
  },
]

interface RemotiveJob {
  id: number
  url: string
  title: string
  company_name: string
  company_logo: string
  category: string
  tags: string[]
  job_type: string
  publication_date: string
  candidate_required_location: string
  salary: string
  description: string
}

interface ArbeitnowJob {
  slug: string
  company_name: string
  title: string
  description: string
  remote: boolean
  url: string
  tags: string[]
  job_types: string[]
  location: string
  created_at: number
}

function parseJSON(text: string): any {
  const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/)
  const jsonStr = jsonMatch ? jsonMatch[1].trim() : text.trim()
  return JSON.parse(jsonStr)
}

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's resume
    const { data: resumeData } = await supabase
      .from("resumes")
      .select("parsed_data")
      .eq("user_id", user.id)
      .maybeSingle()

    if (!resumeData?.parsed_data) {
      return NextResponse.json({ error: "Please upload your resume first" }, { status: 400 })
    }

    const resume = resumeData.parsed_data as any
    const userSkills = resume.skills?.map((s: any) => s.name.toLowerCase()) || []
    const userExperience = resume.experience || []

    // Fetch jobs from multiple sources
    const allJobs: any[] = []

    // Fetch from Remotive API
    try {
      const remotiveRes = await fetch("https://remotive.com/api/remote-jobs?limit=50", {
        headers: { Accept: "application/json" },
      })
      if (remotiveRes.ok) {
        const remotiveData = await remotiveRes.json()
        const remotiveJobs = (remotiveData.jobs || []).map((job: RemotiveJob) => ({
          source: "Remotive",
          external_id: `remotive_${job.id}`,
          title: job.title,
          company: job.company_name,
          company_logo: job.company_logo,
          location: job.candidate_required_location || "Remote",
          type: job.job_type,
          salary: job.salary || "Not specified",
          url: job.url,
          description: job.description,
          tags: job.tags || [],
          category: job.category,
          posted_at: job.publication_date,
        }))
        allJobs.push(...remotiveJobs)
      }
    } catch (e) {
      console.log("[v0] Remotive fetch failed:", e)
    }

    // Fetch from Arbeitnow API
    try {
      const arbeitnowRes = await fetch("https://www.arbeitnow.com/api/job-board-api", {
        headers: { Accept: "application/json" },
      })
      if (arbeitnowRes.ok) {
        const arbeitnowData = await arbeitnowRes.json()
        const arbeitnowJobs = (arbeitnowData.data || []).slice(0, 50).map((job: ArbeitnowJob) => ({
          source: "Arbeitnow",
          external_id: `arbeitnow_${job.slug}`,
          title: job.title,
          company: job.company_name,
          location: job.location || (job.remote ? "Remote" : "On-site"),
          type: job.job_types?.[0] || "Full-time",
          salary: "Not specified",
          url: job.url,
          description: job.description,
          tags: job.tags || [],
          category: job.tags?.[0] || "General",
          posted_at: new Date(job.created_at * 1000).toISOString(),
        }))
        allJobs.push(...arbeitnowJobs)
      }
    } catch (e) {
      console.log("[v0] Arbeitnow fetch failed:", e)
    }

    if (allJobs.length === 0) {
      return NextResponse.json({ error: "Could not fetch jobs from any source" }, { status: 500 })
    }

    // Use AI to match and rank jobs based on user's resume
    const { text } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: `You are a job matching expert. Analyze these job listings and match them to the candidate's profile.

CANDIDATE PROFILE:
- Skills: ${userSkills.join(", ")}
- Experience: ${userExperience.map((e: any) => `${e.title} at ${e.company}`).join("; ")}
- Summary: ${resume.summary || "Not provided"}

JOB LISTINGS (first 30):
${JSON.stringify(allJobs.slice(0, 30), null, 2)}

For each job, calculate a match score (0-100) based on:
1. Skill overlap (40% weight)
2. Experience relevance (30% weight)  
3. Role alignment (30% weight)

Return a JSON array with ONLY the top 15 best-matching jobs, each containing:
{
  "external_id": "the job's external_id",
  "match_score": number (0-100),
  "match_reasons": ["reason1", "reason2", "reason3"],
  "skills_matched": ["skill1", "skill2"],
  "skills_missing": ["skill1", "skill2"],
  "recommendation": "brief personalized recommendation"
}

Return ONLY the JSON array, no other text.`,
    })

    const matchResults = parseJSON(text)

    // Combine job data with match results
    const matchedJobs = matchResults
      .map((match: any) => {
        const job = allJobs.find((j) => j.external_id === match.external_id)
        if (!job) return null
        return {
          ...job,
          match_score: match.match_score,
          match_reasons: match.match_reasons,
          skills_matched: match.skills_matched,
          skills_missing: match.skills_missing,
          recommendation: match.recommendation,
        }
      })
      .filter(Boolean)
      .sort((a: any, b: any) => b.match_score - a.match_score)

    // Store matched jobs in database
    for (const job of matchedJobs.slice(0, 10)) {
      await supabase.from("job_matches").upsert(
        {
          user_id: user.id,
          job_title: job.title,
          company: job.company,
          job_url: job.url,
          match_score: job.match_score,
          match_reasons: job.match_reasons,
          job_data: job,
          status: "new",
        },
        {
          onConflict: "user_id,job_url",
        },
      )
    }

    return NextResponse.json({
      success: true,
      jobs: matchedJobs,
      sources: JOB_SOURCES.map((s) => s.name),
      total_scraped: allJobs.length,
    })
  } catch (error) {
    console.error("[v0] Job scraping error:", error)
    return NextResponse.json(
      {
        error: "Failed to scrape and match jobs",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

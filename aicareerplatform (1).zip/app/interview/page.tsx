"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { DashboardNav } from "@/components/dashboard-nav"
import { InterviewPrepForm } from "@/components/interview-prep-form"
import { InterviewPrepView } from "@/components/interview-prep-view"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Building2, Calendar, Plus } from "lucide-react"
import type { InterviewPrep } from "@/lib/types"

interface PrepSummary {
  id: string
  companyName: string
  role: string
  technologies: string[]
  status: string
  createdAt: string
}

export default function InterviewPage() {
  const [preps, setPreps] = useState<PrepSummary[]>([])
  const [selectedPrep, setSelectedPrep] = useState<InterviewPrep | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isGenerating, setIsGenerating] = useState(false)
  const router = useRouter()

  useEffect(() => {
    async function loadPreps() {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const response = await fetch("/api/interview-prep")
      if (response.ok) {
        const data = await response.json()
        setPreps(data.preps || [])
      }

      setIsLoading(false)
    }

    loadPreps()
  }, [router])

  const handleSubmit = async (data: { companyName: string; role: string; technologies: string[] }) => {
    setIsGenerating(true)
    try {
      const response = await fetch("/api/interview-prep", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error("Failed to generate prep materials")
      }

      const result = await response.json()
      setSelectedPrep(result.prep)
      setShowForm(false)

      // Refresh preps list
      const prepsResponse = await fetch("/api/interview-prep")
      if (prepsResponse.ok) {
        const prepsData = await prepsResponse.json()
        setPreps(prepsData.preps || [])
      }
    } catch (error) {
      console.error("Error generating prep:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const loadPrepDetails = async (id: string) => {
    const response = await fetch(`/api/interview-prep?id=${id}`)
    if (response.ok) {
      const data = await response.json()
      setSelectedPrep(data.prep)
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <main className="flex-1 p-6 lg:p-8">
          <div className="flex h-full items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardNav />
      <main className="flex-1 overflow-auto p-6 lg:p-8">
        <div className="mx-auto max-w-6xl">
          {/* Back button and header */}
          {selectedPrep ? (
            <>
              <Button
                variant="ghost"
                onClick={() => setSelectedPrep(null)}
                className="mb-4 gap-2 text-muted-foreground hover:text-foreground"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Preparations
              </Button>
              <InterviewPrepView prep={selectedPrep} />
            </>
          ) : showForm ? (
            <>
              <Button
                variant="ghost"
                onClick={() => setShowForm(false)}
                className="mb-4 gap-2 text-muted-foreground hover:text-foreground"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Preparations
              </Button>
              <InterviewPrepForm onSubmit={handleSubmit} isLoading={isGenerating} />
            </>
          ) : (
            <>
              <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-foreground">Interview Preparation</h1>
                  <p className="mt-1 text-muted-foreground">AI-generated prep materials for your upcoming interviews</p>
                </div>
                <Button
                  onClick={() => setShowForm(true)}
                  className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  <Plus className="h-4 w-4" />
                  New Preparation
                </Button>
              </div>

              {preps.length === 0 ? (
                <Card className="border-border bg-card py-12 text-center">
                  <CardContent>
                    <Building2 className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                    <h3 className="text-lg font-semibold text-foreground">No interview preparations yet</h3>
                    <p className="mt-2 text-muted-foreground">
                      Start by creating a new interview preparation with company and role details
                    </p>
                    <Button
                      onClick={() => setShowForm(true)}
                      className="mt-6 gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                    >
                      <Plus className="h-4 w-4" />
                      Create First Preparation
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {preps.map((prep) => (
                    <Card
                      key={prep.id}
                      className="cursor-pointer border-border bg-card transition-all hover:border-primary/50"
                      onClick={() => loadPrepDetails(prep.id)}
                    >
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg text-foreground">{prep.role}</CardTitle>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Building2 className="h-4 w-4" />
                          {prep.companyName}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="mb-3 flex flex-wrap gap-1">
                          {prep.technologies.slice(0, 4).map((tech) => (
                            <Badge
                              key={tech}
                              variant="secondary"
                              className="bg-secondary text-xs text-secondary-foreground"
                            >
                              {tech}
                            </Badge>
                          ))}
                          {prep.technologies.length > 4 && (
                            <Badge variant="outline" className="text-xs text-muted-foreground">
                              +{prep.technologies.length - 4}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(prep.createdAt).toLocaleDateString()}
                          </span>
                          <Badge
                            variant="secondary"
                            className={`${
                              prep.status === "completed"
                                ? "bg-green-500/20 text-green-400"
                                : "bg-yellow-500/20 text-yellow-400"
                            }`}
                          >
                            {prep.status}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  )
}

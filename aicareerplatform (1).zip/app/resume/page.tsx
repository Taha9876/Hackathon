"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { ResumeUpload } from "@/components/resume-upload"
import { ResumeInsights } from "@/components/resume-insights"
import { DashboardNav } from "@/components/dashboard-nav"
import { Button } from "@/components/ui/button"
import { ArrowRight, RefreshCw } from "lucide-react"
import Link from "next/link"
import type { ParsedResume } from "@/lib/types"

export default function ResumePage() {
  const [resume, setResume] = useState<ParsedResume | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showUpload, setShowUpload] = useState(false)
  const router = useRouter()

  useEffect(() => {
    async function loadResume() {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase.from("resumes").select("*").eq("user_id", user.id).maybeSingle()

      if (data?.parsed_data) {
        const parsedData = data.parsed_data as ParsedResume
        setResume(parsedData)
      }
      setIsLoading(false)
    }

    loadResume()
  }, [router])

  const handleUploadSuccess = (parsedResume: ParsedResume) => {
    setResume(parsedResume)
    setShowUpload(false)
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <main className="flex-1 p-6 lg:p-8">
          <div className="flex h-full items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardNav />
      <main className="flex-1 overflow-auto p-6 lg:p-8">
        <div className="mx-auto max-w-4xl">
          <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Resume Analysis</h1>
              <p className="mt-1 text-muted-foreground">
                {resume ? "Your AI-analyzed professional profile" : "Upload your resume to get started"}
              </p>
            </div>
            {resume && !showUpload && (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowUpload(true)}
                  className="gap-2 border-border text-foreground hover:bg-secondary"
                >
                  <RefreshCw className="h-4 w-4" />
                  Update Resume
                </Button>
                <Link href="/jobs">
                  <Button className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
                    Find Jobs
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            )}
          </div>

          {!resume || showUpload ? (
            <ResumeUpload onSuccess={handleUploadSuccess} />
          ) : (
            <ResumeInsights resume={resume} />
          )}
        </div>
      </main>
    </div>
  )
}

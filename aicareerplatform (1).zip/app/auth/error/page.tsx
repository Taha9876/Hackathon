import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Sparkles } from "lucide-react"
import Link from "next/link"

export default async function AuthErrorPage({
  searchParams,
}: {
  searchParams: Promise<{ error: string }>
}) {
  const params = await searchParams

  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background p-6">
      <Link href="/" className="mb-8 flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
          <Sparkles className="h-6 w-6 text-primary-foreground" />
        </div>
        <span className="text-xl font-semibold text-foreground">CareerLaunch</span>
      </Link>
      <Card className="w-full max-w-md border-border bg-card">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10">
            <AlertCircle className="h-8 w-8 text-destructive" />
          </div>
          <CardTitle className="text-2xl text-foreground">Authentication Error</CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          {params?.error ? (
            <p className="text-sm text-muted-foreground">Error: {params.error}</p>
          ) : (
            <p className="text-sm text-muted-foreground">An unexpected error occurred during authentication.</p>
          )}
          <Link href="/auth/login" className="mt-6 inline-block text-sm text-primary hover:underline">
            Try again
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}

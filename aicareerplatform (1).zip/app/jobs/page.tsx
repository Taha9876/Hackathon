"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { DashboardNav } from "@/components/dashboard-nav"
import { JobCard } from "@/components/job-card"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  RefreshCw,
  Briefcase,
  Bookmark,
  CheckCircle,
  AlertCircle,
  FileText,
  DollarSign,
  TrendingUp,
  Globe,
} from "lucide-react"
import Link from "next/link"
import type { JobMatch } from "@/lib/types"

export default function JobsPage() {
  const [jobs, setJobs] = useState<JobMatch[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDiscovering, setIsDiscovering] = useState(false)
  const [hasResume, setHasResume] = useState(false)
  const [discoveryStatus, setDiscoveryStatus] = useState<string>("")
  const [filters, setFilters] = useState({
    location: "",
    sortBy: "compatibility",
    jobType: "all",
    experienceLevel: "all",
    minSalary: "",
  })
  const [activeTab, setActiveTab] = useState("all")
  const router = useRouter()

  const mapDbJobToJobMatch = (job: any): JobMatch => ({
    id: job.id,
    title: job.title || job.job_title,
    company: job.company,
    location: job.location || "Remote",
    description: job.description || "",
    requirements: job.requirements || [],
    qualifications: job.qualifications || [],
    responsibilities: job.responsibilities || [],
    url: job.url || job.job_url || "",
    source: job.source || "AI Generated",
    compatibilityScore: job.compatibility_score || job.match_score || 0,
    matchReasons: job.match_reasons || [],
    skillsMatched: job.skills_matched || [],
    skillsGap: job.skills_gap || [],
    status: job.status || "new",
    saved: job.saved || false,
    applied: job.applied || false,
    createdAt: job.created_at,
    salary: job.salary,
    jobType: job.job_type || "full-time",
    experienceLevel: job.experience_level || "mid",
    postedDate: job.posted_date,
    benefits: job.benefits || [],
    companyInfo: job.company_info,
  })

  useEffect(() => {
    async function loadData() {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data: resumeData } = await supabase.from("resumes").select("id").eq("user_id", user.id).maybeSingle()

      setHasResume(!!resumeData)

      const { data: jobsData } = await supabase
        .from("job_matches")
        .select("*")
        .eq("user_id", user.id)
        .order("compatibility_score", { ascending: false })

      if (jobsData) {
        setJobs(jobsData.map(mapDbJobToJobMatch))
      }

      setIsLoading(false)
    }

    loadData()
  }, [router])

  const discoverJobs = async () => {
    setIsDiscovering(true)
    setDiscoveryStatus("Searching job boards...")

    try {
      setDiscoveryStatus("Scraping real job listings from Remotive & Arbeitnow...")
      const scrapeResponse = await fetch("/api/scrape-jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      })

      let realJobsFound = false
      if (scrapeResponse.ok) {
        const scrapeResult = await scrapeResponse.json()
        if (scrapeResult.jobs && scrapeResult.jobs.length > 0) {
          realJobsFound = true
          setDiscoveryStatus(`Found ${scrapeResult.jobs.length} real jobs! Analyzing matches...`)
        }
      }

      if (!realJobsFound) {
        setDiscoveryStatus("Generating AI-matched job opportunities...")
        const response = await fetch("/api/discover-jobs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ filters }),
        })

        const result = await response.json()

        if (!response.ok) {
          throw new Error(result.error || "Failed to discover jobs")
        }
      }

      setDiscoveryStatus("Loading matched jobs...")
      const supabase = createClient()
      const { data: jobsData } = await supabase
        .from("job_matches")
        .select("*")
        .order("compatibility_score", { ascending: false })

      if (jobsData) {
        setJobs(jobsData.map(mapDbJobToJobMatch))
      }

      setDiscoveryStatus("")
    } catch (error) {
      console.error("Job discovery error:", error)
      setDiscoveryStatus("Error discovering jobs. Please try again.")
      setTimeout(() => setDiscoveryStatus(""), 3000)
    } finally {
      setIsDiscovering(false)
    }
  }

  const handleJobUpdate = (id: string, updates: Partial<JobMatch>) => {
    setJobs((prev) => prev.map((job) => (job.id === id ? { ...job, ...updates } : job)))
  }

  const filteredJobs = jobs.filter((job) => {
    if (activeTab === "saved" && !job.saved) return false
    if (activeTab === "applied" && !job.applied) return false
    if (filters.jobType !== "all" && job.jobType !== filters.jobType) return false
    if (filters.experienceLevel !== "all" && job.experienceLevel !== filters.experienceLevel) return false
    if (filters.minSalary && job.salary?.min && job.salary.min < Number.parseInt(filters.minSalary)) return false
    return true
  })

  const sortedJobs = [...filteredJobs].sort((a, b) => {
    if (filters.sortBy === "compatibility") {
      return b.compatibilityScore - a.compatibilityScore
    }
    if (filters.sortBy === "salary") {
      const salaryA = a.salary?.max || a.salary?.min || 0
      const salaryB = b.salary?.max || b.salary?.min || 0
      return salaryB - salaryA
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  })

  const stats = {
    total: jobs.length,
    saved: jobs.filter((j) => j.saved).length,
    applied: jobs.filter((j) => j.applied).length,
    avgScore: jobs.length > 0 ? Math.round(jobs.reduce((acc, j) => acc + j.compatibilityScore, 0) / jobs.length) : 0,
    avgSalary:
      jobs.length > 0
        ? Math.round(
            jobs.filter((j) => j.salary?.min).reduce((acc, j) => acc + (j.salary?.min || 0), 0) /
              Math.max(jobs.filter((j) => j.salary?.min).length, 1),
          )
        : 0,
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <main className="flex-1 p-6 lg:p-8">
          <div className="flex h-full items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        </main>
      </div>
    )
  }

  if (!hasResume) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <main className="flex-1 p-6 lg:p-8">
          <div className="mx-auto max-w-2xl">
            <Card className="border-border bg-card text-center">
              <CardHeader>
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-foreground">Upload Your Resume First</CardTitle>
                <CardDescription className="text-muted-foreground">
                  To discover job matches, we need to analyze your resume and understand your skills and experience.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/resume">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Upload Resume</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardNav />
      <main className="flex-1 overflow-auto p-6 lg:p-8">
        <div className="mx-auto max-w-6xl">
          {/* Header */}
          <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Job Discovery</h1>
              <p className="mt-1 text-muted-foreground">
                {discoveryStatus || "AI-matched opportunities based on your resume"}
              </p>
            </div>
            <Button
              onClick={discoverJobs}
              disabled={isDiscovering}
              className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {isDiscovering ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Globe className="h-4 w-4" />}
              {isDiscovering ? "Discovering..." : "Discover Jobs"}
            </Button>
          </div>

          {/* Stats Cards */}
          <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Briefcase className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.total}</p>
                  <p className="text-xs text-muted-foreground">Total Matches</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                  <TrendingUp className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.avgScore}%</p>
                  <p className="text-xs text-muted-foreground">Avg Match</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
                  <DollarSign className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">
                    {stats.avgSalary > 0 ? `$${Math.round(stats.avgSalary / 1000)}k` : "-"}
                  </p>
                  <p className="text-xs text-muted-foreground">Avg Salary</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-500/10">
                  <Bookmark className="h-5 w-5 text-yellow-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.saved}</p>
                  <p className="text-xs text-muted-foreground">Saved</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.applied}</p>
                  <p className="text-xs text-muted-foreground">Applied</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="mb-6 border-border bg-card">
            <CardContent className="grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-5">
              <div>
                <Label className="text-foreground">Location</Label>
                <Input
                  placeholder="e.g., Remote, San Francisco"
                  value={filters.location}
                  onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                  className="mt-1 border-input bg-secondary text-foreground"
                />
              </div>
              <div>
                <Label className="text-foreground">Job Type</Label>
                <Select value={filters.jobType} onValueChange={(value) => setFilters({ ...filters, jobType: value })}>
                  <SelectTrigger className="mt-1 border-input bg-secondary text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-border bg-card">
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="full-time">Full-time</SelectItem>
                    <SelectItem value="part-time">Part-time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="remote">Remote</SelectItem>
                    <SelectItem value="internship">Internship</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-foreground">Experience Level</Label>
                <Select
                  value={filters.experienceLevel}
                  onValueChange={(value) => setFilters({ ...filters, experienceLevel: value })}
                >
                  <SelectTrigger className="mt-1 border-input bg-secondary text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-border bg-card">
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="entry">Entry Level</SelectItem>
                    <SelectItem value="mid">Mid Level</SelectItem>
                    <SelectItem value="senior">Senior</SelectItem>
                    <SelectItem value="lead">Lead/Principal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-foreground">Min Salary ($)</Label>
                <Input
                  type="number"
                  placeholder="e.g., 100000"
                  value={filters.minSalary}
                  onChange={(e) => setFilters({ ...filters, minSalary: e.target.value })}
                  className="mt-1 border-input bg-secondary text-foreground"
                />
              </div>
              <div>
                <Label className="text-foreground">Sort By</Label>
                <Select value={filters.sortBy} onValueChange={(value) => setFilters({ ...filters, sortBy: value })}>
                  <SelectTrigger className="mt-1 border-input bg-secondary text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-border bg-card">
                    <SelectItem value="compatibility">Match Score</SelectItem>
                    <SelectItem value="salary">Highest Salary</SelectItem>
                    <SelectItem value="date">Most Recent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="bg-muted">
              <TabsTrigger
                value="all"
                className="data-[state=active]:bg-background data-[state=active]:text-foreground"
              >
                All Jobs ({jobs.length})
              </TabsTrigger>
              <TabsTrigger
                value="saved"
                className="data-[state=active]:bg-background data-[state=active]:text-foreground"
              >
                Saved ({stats.saved})
              </TabsTrigger>
              <TabsTrigger
                value="applied"
                className="data-[state=active]:bg-background data-[state=active]:text-foreground"
              >
                Applied ({stats.applied})
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="space-y-4">
              {sortedJobs.length === 0 ? (
                <Card className="border-border bg-card py-12 text-center">
                  <CardContent>
                    <AlertCircle className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                    <h3 className="text-lg font-semibold text-foreground">
                      {activeTab === "all"
                        ? "No jobs discovered yet"
                        : activeTab === "saved"
                          ? "No saved jobs"
                          : "No applications yet"}
                    </h3>
                    <p className="mt-2 text-muted-foreground">
                      {activeTab === "all"
                        ? "Click 'Discover Jobs' to find opportunities matching your profile"
                        : "Jobs you save or apply to will appear here"}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4 lg:grid-cols-2">
                  {sortedJobs.map((job) => (
                    <JobCard key={job.id} job={job} onUpdate={handleJobUpdate} />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

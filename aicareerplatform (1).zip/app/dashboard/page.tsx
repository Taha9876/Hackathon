"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { DashboardNav } from "@/components/dashboard-nav"
import { RecommendationsPanel } from "@/components/recommendations-panel"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import {
  FileText,
  Briefcase,
  MessageSquare,
  Upload,
  Search,
  ArrowRight,
  TrendingUp,
  Target,
  Zap,
  CheckCircle,
  Star,
  ChevronRight,
  Sparkles,
  LayoutDashboard,
} from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import type { ParsedResume, Skill } from "@/lib/types"

interface DashboardData {
  hasResume: boolean
  resume: ParsedResume | null
  jobStats: {
    total: number
    saved: number
    applied: number
    avgScore: number
    topSkillsMatched: { name: string; count: number }[]
  }
  interviewStats: {
    total: number
    completed: number
    upcoming: { companyName: string; role: string; id: string }[]
  }
  recentJobs: {
    id: string
    title: string
    company: string
    compatibilityScore: number
  }[]
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [activeTab, setActiveTab] = useState("overview")
  const router = useRouter()

  useEffect(() => {
    async function loadDashboardData() {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      // Get user profile
      const { data: profile } = await supabase.from("profiles").select("full_name, email").eq("id", user.id).single()

      setUserName(profile?.full_name || profile?.email?.split("@")[0] || "there")

      // Get resume data
      const { data: resumeData } = await supabase.from("resumes").select("*").eq("user_id", user.id).single()

      // Get job matches stats
      const { data: jobsData } = await supabase
        .from("job_matches")
        .select("*")
        .eq("user_id", user.id)
        .order("compatibility_score", { ascending: false })

      // Get interview preps
      const { data: interviewData } = await supabase
        .from("interview_preps")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      // Calculate stats
      const jobs = jobsData || []
      const interviews = interviewData || []

      // Calculate top matched skills
      const skillCounts: Record<string, number> = {}
      jobs.forEach((job) => {
        ;(job.skills_matched || []).forEach((skill: string) => {
          skillCounts[skill] = (skillCounts[skill] || 0) + 1
        })
      })
      const topSkillsMatched = Object.entries(skillCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
        .map(([name, count]) => ({ name, count }))

      setData({
        hasResume: !!resumeData?.parsed_data,
        resume: resumeData?.parsed_data || null,
        jobStats: {
          total: jobs.length,
          saved: jobs.filter((j) => j.saved).length,
          applied: jobs.filter((j) => j.applied).length,
          avgScore:
            jobs.length > 0 ? Math.round(jobs.reduce((acc, j) => acc + j.compatibility_score, 0) / jobs.length) : 0,
          topSkillsMatched,
        },
        interviewStats: {
          total: interviews.length,
          completed: interviews.filter((i) => i.status === "completed").length,
          upcoming: interviews.slice(0, 3).map((i) => ({
            companyName: i.company_name,
            role: i.role,
            id: i.id,
          })),
        },
        recentJobs: jobs.slice(0, 5).map((j) => ({
          id: j.id,
          title: j.title,
          company: j.company,
          compatibilityScore: j.compatibility_score,
        })),
      })

      setIsLoading(false)
    }

    loadDashboardData()
  }, [router])

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <main className="flex-1 p-6 lg:p-8">
          <div className="flex h-full items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        </main>
      </div>
    )
  }

  if (!data) return null

  const skillsChartData =
    data.resume?.skills?.reduce((acc: Record<string, number>, skill: Skill) => {
      acc[skill.category] = (acc[skill.category] || 0) + 1
      return acc
    }, {}) || {}

  const skillsByCategoryData = Object.entries(skillsChartData).map(([category, count]) => ({
    category,
    count,
  }))

  const proficiencyData = data.resume?.skills?.reduce(
    (acc: Record<string, number>, skill: Skill) => {
      acc[skill.proficiency] = (acc[skill.proficiency] || 0) + 1
      return acc
    },
    { beginner: 0, intermediate: 0, advanced: 0, expert: 0 },
  ) || { beginner: 0, intermediate: 0, advanced: 0, expert: 0 }

  const pieData = [
    { name: "Expert", value: proficiencyData.expert, color: "#22d3ee" },
    { name: "Advanced", value: proficiencyData.advanced, color: "#3b82f6" },
    { name: "Intermediate", value: proficiencyData.intermediate, color: "#8b5cf6" },
    { name: "Beginner", value: proficiencyData.beginner, color: "#71717a" },
  ].filter((d) => d.value > 0)

  const completionPercentage =
    [data.hasResume, data.jobStats.total > 0, data.interviewStats.total > 0, data.jobStats.applied > 0].filter(Boolean)
      .length * 25

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardNav />
      <main className="flex-1 overflow-auto p-6 lg:p-8">
        <div className="mx-auto max-w-7xl space-y-6">
          {/* Welcome Header */}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Welcome back, {userName}</h1>
              <p className="mt-1 text-muted-foreground">Here&apos;s an overview of your career journey</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="gap-1 bg-primary/10 px-3 py-1 text-primary">
                <Zap className="h-3 w-3" />
                {completionPercentage}% Profile Complete
              </Badge>
            </div>
          </div>

          {/* Quick Actions / Getting Started */}
          {!data.hasResume ? (
            <Card className="border-primary/50 bg-gradient-to-br from-primary/10 to-accent/10">
              <CardContent className="flex flex-col items-center gap-4 p-8 text-center sm:flex-row sm:text-left">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/20">
                  <Upload className="h-8 w-8 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-foreground">Start by uploading your resume</h3>
                  <p className="mt-1 text-muted-foreground">
                    Upload your resume to unlock AI-powered job matching and personalized interview preparation
                  </p>
                </div>
                <Link href="/resume">
                  <Button className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
                    Upload Resume
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            /* Tabs for Overview and Recommendations */
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="bg-muted">
                <TabsTrigger value="overview" className="gap-2">
                  <LayoutDashboard className="h-4 w-4" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="recommendations" className="gap-2">
                  <Sparkles className="h-4 w-4" />
                  AI Recommendations
                </TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                {/* Progress Overview */}
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <Card className="border-border bg-card">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Resume</p>
                          <p className="text-2xl font-bold text-foreground">Analyzed</p>
                        </div>
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500/10">
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        </div>
                      </div>
                      <Progress value={100} className="mt-3 h-1.5" />
                    </CardContent>
                  </Card>
                  <Card className="border-border bg-card">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Job Matches</p>
                          <p className="text-2xl font-bold text-foreground">{data.jobStats.total}</p>
                        </div>
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                          <Briefcase className="h-5 w-5 text-primary" />
                        </div>
                      </div>
                      <div className="mt-3 flex gap-2 text-xs text-muted-foreground">
                        <span>{data.jobStats.saved} saved</span>
                        <span>•</span>
                        <span>{data.jobStats.applied} applied</span>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="border-border bg-card">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Avg Match Score</p>
                          <p className="text-2xl font-bold text-foreground">{data.jobStats.avgScore}%</p>
                        </div>
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10">
                          <Target className="h-5 w-5 text-accent" />
                        </div>
                      </div>
                      <Progress value={data.jobStats.avgScore} className="mt-3 h-1.5" />
                    </CardContent>
                  </Card>
                  <Card className="border-border bg-card">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Interview Preps</p>
                          <p className="text-2xl font-bold text-foreground">{data.interviewStats.total}</p>
                        </div>
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-yellow-500/10">
                          <MessageSquare className="h-5 w-5 text-yellow-500" />
                        </div>
                      </div>
                      <div className="mt-3 flex gap-2 text-xs text-muted-foreground">
                        <span>{data.interviewStats.completed} completed</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Main Content Grid */}
                <div className="grid gap-6 lg:grid-cols-3">
                  {/* Left Column - Skills Analysis */}
                  <div className="space-y-6 lg:col-span-2">
                    {data.resume && (
                      <>
                        {/* Skills by Category Chart */}
                        <Card className="border-border bg-card">
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-foreground">
                              <TrendingUp className="h-5 w-5 text-primary" />
                              Skills Distribution
                            </CardTitle>
                            <CardDescription className="text-muted-foreground">
                              {data.resume.skills.length} skills across {Object.keys(skillsChartData).length} categories
                            </CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="h-64">
                              <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={skillsByCategoryData} layout="vertical">
                                  <XAxis type="number" stroke="#71717a" />
                                  <YAxis
                                    dataKey="category"
                                    type="category"
                                    width={120}
                                    stroke="#71717a"
                                    tick={{ fill: "#a1a1aa", fontSize: 12 }}
                                  />
                                  <Tooltip
                                    contentStyle={{
                                      backgroundColor: "#18181f",
                                      border: "1px solid #27272a",
                                      borderRadius: "8px",
                                    }}
                                    labelStyle={{ color: "#f5f5f7" }}
                                  />
                                  <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Top Matched Skills */}
                        {data.jobStats.topSkillsMatched.length > 0 && (
                          <Card className="border-border bg-card">
                            <CardHeader>
                              <CardTitle className="flex items-center gap-2 text-foreground">
                                <Star className="h-5 w-5 text-yellow-500" />
                                Most In-Demand Skills
                              </CardTitle>
                              <CardDescription className="text-muted-foreground">
                                Skills that appear most frequently in your job matches
                              </CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-3">
                                {data.jobStats.topSkillsMatched.map((skill) => (
                                  <div key={skill.name} className="flex items-center gap-3">
                                    <span className="w-32 truncate text-sm font-medium text-foreground">
                                      {skill.name}
                                    </span>
                                    <div className="flex-1">
                                      <Progress value={(skill.count / data.jobStats.total) * 100} className="h-2" />
                                    </div>
                                    <span className="w-16 text-right text-sm text-muted-foreground">
                                      {skill.count} jobs
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </>
                    )}

                    {/* Recent Job Matches */}
                    <Card className="border-border bg-card">
                      <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2 text-foreground">
                            <Briefcase className="h-5 w-5 text-primary" />
                            Recent Job Matches
                          </CardTitle>
                        </div>
                        <Link href="/jobs">
                          <Button variant="ghost" size="sm" className="gap-1 text-primary">
                            View All
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </CardHeader>
                      <CardContent>
                        {data.recentJobs.length === 0 ? (
                          <div className="py-8 text-center">
                            <Search className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
                            <p className="text-muted-foreground">No job matches yet</p>
                            <Link href="/jobs">
                              <Button
                                variant="outline"
                                size="sm"
                                className="mt-3 border-border bg-transparent text-foreground hover:bg-secondary"
                              >
                                Discover Jobs
                              </Button>
                            </Link>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            {data.recentJobs.map((job) => (
                              <div key={job.id} className="flex items-center justify-between rounded-lg bg-muted p-3">
                                <div>
                                  <p className="font-medium text-foreground">{job.title}</p>
                                  <p className="text-sm text-muted-foreground">{job.company}</p>
                                </div>
                                <Badge
                                  variant="secondary"
                                  className={`${
                                    job.compatibilityScore >= 80
                                      ? "bg-green-500/20 text-green-400"
                                      : job.compatibilityScore >= 60
                                        ? "bg-primary/20 text-primary"
                                        : "bg-secondary text-secondary-foreground"
                                  }`}
                                >
                                  {job.compatibilityScore}% match
                                </Badge>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  {/* Right Column */}
                  <div className="space-y-6">
                    {/* Skill Proficiency Pie Chart */}
                    {pieData.length > 0 && (
                      <Card className="border-border bg-card">
                        <CardHeader>
                          <CardTitle className="text-foreground">Skill Proficiency</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-48">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={pieData}
                                  dataKey="value"
                                  nameKey="name"
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={40}
                                  outerRadius={70}
                                  paddingAngle={2}
                                >
                                  {pieData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                                </Pie>
                                <Tooltip
                                  contentStyle={{
                                    backgroundColor: "#18181f",
                                    border: "1px solid #27272a",
                                    borderRadius: "8px",
                                  }}
                                />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                          <div className="mt-4 grid grid-cols-2 gap-2">
                            {pieData.map((item) => (
                              <div key={item.name} className="flex items-center gap-2">
                                <div className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                                <span className="text-xs text-muted-foreground">
                                  {item.name}: {item.value}
                                </span>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Interview Preps */}
                    <Card className="border-border bg-card">
                      <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle className="flex items-center gap-2 text-foreground">
                          <MessageSquare className="h-5 w-5 text-yellow-500" />
                          Interview Preps
                        </CardTitle>
                        <Link href="/interview">
                          <Button variant="ghost" size="sm" className="gap-1 text-primary">
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </CardHeader>
                      <CardContent>
                        {data.interviewStats.upcoming.length === 0 ? (
                          <div className="py-4 text-center">
                            <p className="text-sm text-muted-foreground">No interview preps yet</p>
                            <Link href="/interview">
                              <Button
                                variant="outline"
                                size="sm"
                                className="mt-3 border-border bg-transparent text-foreground hover:bg-secondary"
                              >
                                Start Preparing
                              </Button>
                            </Link>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            {data.interviewStats.upcoming.map((prep) => (
                              <Link key={prep.id} href={`/interview?id=${prep.id}`}>
                                <div className="rounded-lg bg-muted p-3 transition-colors hover:bg-muted/80">
                                  <p className="font-medium text-foreground">{prep.companyName}</p>
                                  <p className="text-sm text-muted-foreground">{prep.role}</p>
                                </div>
                              </Link>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Quick Actions */}
                    <Card className="border-border bg-card">
                      <CardHeader>
                        <CardTitle className="text-foreground">Quick Actions</CardTitle>
                      </CardHeader>
                      <CardContent className="grid gap-2">
                        <Link href="/resume">
                          <Button
                            variant="outline"
                            className="w-full justify-start gap-2 border-border bg-transparent text-foreground hover:bg-secondary"
                          >
                            <FileText className="h-4 w-4 text-primary" />
                            Update Resume
                          </Button>
                        </Link>
                        <Link href="/jobs">
                          <Button
                            variant="outline"
                            className="w-full justify-start gap-2 border-border bg-transparent text-foreground hover:bg-secondary"
                          >
                            <Search className="h-4 w-4 text-primary" />
                            Discover New Jobs
                          </Button>
                        </Link>
                        <Link href="/interview">
                          <Button
                            variant="outline"
                            className="w-full justify-start gap-2 border-border bg-transparent text-foreground hover:bg-secondary"
                          >
                            <MessageSquare className="h-4 w-4 text-primary" />
                            Prepare for Interview
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              {/* Recommendations Tab */}
              <TabsContent value="recommendations">
                <RecommendationsPanel />
              </TabsContent>
            </Tabs>
          )}
        </div>
      </main>
    </div>
  )
}

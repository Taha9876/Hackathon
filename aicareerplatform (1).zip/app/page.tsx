import { AnimatedLanding } from "@/components/animated-landing"

export default function HomePage() {
  return <AnimatedLanding />
}

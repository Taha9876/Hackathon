-- Add new columns to job_matches table for enhanced job data
ALTER TABLE job_matches 
ADD COLUMN IF NOT EXISTS qualifications jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS responsibilities jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS skills_gap jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS salary jsonb,
ADD COLUMN IF NOT EXISTS job_type text DEFAULT 'full-time',
ADD COLUMN IF NOT EXISTS experience_level text DEFAULT 'mid',
ADD COLUMN IF NOT EXISTS posted_date timestamp with time zone,
ADD COLUMN IF NOT EXISTS application_deadline timestamp with time zone,
ADD COLUMN IF NOT EXISTS benefits jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS company_info jsonb;

-- Add index for faster filtering
CREATE INDEX IF NOT EXISTS idx_job_matches_job_type ON job_matches(job_type);
CREATE INDEX IF NOT EXISTS idx_job_matches_experience_level ON job_matches(experience_level);

-- Add unique constraint on user_id for resumes table to enable upsert
ALTER TABLE public.resumes DROP CONSTRAINT IF EXISTS resumes_user_id_unique;
ALTER TABLE public.resumes ADD CONSTRAINT resumes_user_id_unique UNIQUE (user_id);

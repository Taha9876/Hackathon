-- Add additional columns to job_matches for enhanced job data
ALTER TABLE public.job_matches 
ADD COLUMN IF NOT EXISTS job_url TEXT,
ADD COLUMN IF NOT EXISTS job_title TEXT,
ADD COLUMN IF NOT EXISTS job_data JSONB,
ADD COLUMN IF NOT EXISTS skills_gap JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS qualifications JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS responsibilities JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS salary JSONB,
ADD COLUMN IF NOT EXISTS job_type TEXT DEFAULT 'full-time',
ADD COLUMN IF NOT EXISTS experience_level TEXT DEFAULT 'mid',
ADD COLUMN IF NOT EXISTS posted_date TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS benefits JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS company_info JSONB;

-- Create unique constraint on user_id and job_url for upsert
CREATE UNIQUE INDEX IF NOT EXISTS idx_job_matches_user_job_url ON public.job_matches(user_id, job_url);

export interface Skill {
  name: string
  category: string
  proficiency: "beginner" | "intermediate" | "advanced" | "expert"
}

export interface Experience {
  title: string
  company: string
  location?: string
  startDate: string
  endDate?: string
  current: boolean
  description: string
  highlights: string[]
}

export interface Education {
  degree: string
  institution: string
  location?: string
  graduationDate: string
  gpa?: string
  highlights: string[]
}

export interface Project {
  name: string
  description: string
  technologies: string[]
  url?: string
  highlights: string[]
}

export interface ParsedResume {
  fullName: string
  email?: string
  phone?: string
  location?: string
  linkedin?: string
  github?: string
  portfolio?: string
  summary: string
  skills: Skill[]
  experience: Experience[]
  education: Education[]
  projects: Project[]
  expertiseAreas: string[]
  yearsOfExperience: number
}

export interface JobMatch {
  id: string
  title: string
  company: string
  location: string
  description: string
  requirements: string[]
  qualifications: string[]
  responsibilities: string[]
  url: string
  source: string
  compatibilityScore: number
  matchReasons: string[]
  skillsMatched: string[]
  skillsGap: string[]
  status: "new" | "viewed" | "saved" | "applied" | "rejected"
  saved: boolean
  applied: boolean
  createdAt: string
  // New fields
  salary?: {
    min?: number
    max?: number
    currency: string
    period: "hourly" | "yearly"
  }
  jobType: "full-time" | "part-time" | "contract" | "internship" | "remote"
  experienceLevel: "entry" | "mid" | "senior" | "lead" | "executive"
  postedDate?: string
  applicationDeadline?: string
  benefits?: string[]
  companyInfo?: {
    size?: string
    industry?: string
    founded?: string
    website?: string
  }
}

export interface InterviewPrep {
  id: string
  companyName: string
  role: string
  technologies: string[]
  technicalQuestions: TechnicalQuestion[]
  behavioralQuestions: BehavioralQuestion[]
  companyInsights: CompanyInsight
  tips: string[]
  status: "pending" | "in-progress" | "completed"
  createdAt: string
}

export interface TechnicalQuestion {
  question: string
  topic: string
  difficulty: "easy" | "medium" | "hard"
  hints: string[]
  keyPoints: string[]
}

export interface BehavioralQuestion {
  question: string
  category: string
  starExample: {
    situation: string
    task: string
    action: string
    result: string
  }
}

export interface CompanyInsight {
  overview: string
  culture: string
  techStack: string[]
  interviewProcess: string
  recentNews: string[]
}
